"""Ponto de entrada do jogo. No computador:  python main.py
Também é o arquivo que o pygbag usa para rodar no navegador/celular (por isso o asyncio)."""
import asyncio

from scripts.game import Game


async def main():
    game = Game()
    await game.run_async()


asyncio.run(main())
