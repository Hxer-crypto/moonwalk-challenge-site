"""
touch.py
========
Controles de TOQUE para celular: botões na tela (← →, poder e pausa).

* Aparecem automaticamente na versão web (celular/navegador) e, no computador, assim que a tela
  detecta um toque. Para forçar: settings.TOUCH_UI = True (sempre) ou False (nunca).
* Suporta vários dedos ao mesmo tempo (andar + usar o poder). Se o navegador só mandar eventos de
  "mouse" (um dedo), também funciona, só que um dedo por vez.
"""
import math

import pygame

from scripts import settings

W, H = settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT

_FINGER_EVENTS = tuple(getattr(pygame, n) for n in ("FINGERDOWN", "FINGERMOTION", "FINGERUP") if hasattr(pygame, n))


class TouchControls:
    def __init__(self, game):
        self.game = game
        self.pointers = {}               # id do dedo -> (x, y) em coordenadas do jogo (1280x720)
        self.use_fingers = False         # True depois do 1º evento de dedo (aí ignoramos o "mouse falso")
        # retângulos DESENHADOS e áreas de toque (maiores, para não errar o botão com o polegar)
        self.left = pygame.Rect(0, 0, 150, 132); self.left.center = (118, 628)
        self.right = pygame.Rect(0, 0, 150, 132); self.right.center = (292, 628)
        self.power = pygame.Rect(0, 0, 190, 150); self.power.center = (1150, 618)
        self.pause = pygame.Rect(0, 0, 74, 64); self.pause.center = (W - 52, 128)
        self.hit_left = self.left.inflate(70, 150)
        self.hit_right = self.right.inflate(70, 150)
        self.hit_power = self.power.inflate(90, 120)
        self.hit_pause = self.pause.inflate(50, 40)
        self._font_cache = {}

    # ------------------------------------------------------------ ativação
    @property
    def enabled(self):
        mode = settings.TOUCH_UI
        if mode is True:
            return True
        if mode is False:
            return False
        return settings.IS_WEB or getattr(self.game, "touch_seen", False)

    def reset(self):
        self.pointers.clear()

    # ------------------------------------------------------------ entrada
    def handle_event(self, event):
        """Atualiza os dedos. Devolve uma lista de ações: 'power' e/ou 'pause'."""
        if not self.enabled:
            return []
        actions = []
        t = event.type
        if t in _FINGER_EVENTS:
            self.use_fingers = True
            pos = (event.x * W, event.y * H)
            fid = getattr(event, "finger_id", 0)
            if t == pygame.FINGERUP:
                self.pointers.pop(fid, None)
            else:
                self.pointers[fid] = pos
                if t == pygame.FINGERDOWN:
                    actions += self._taps(pos)
        elif not self.use_fingers:       # sem eventos de dedo: usa o mouse / toque emulado como mouse
            if t == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self.pointers["mouse"] = event.pos
                actions += self._taps(event.pos)
            elif t == pygame.MOUSEMOTION and event.buttons[0]:
                self.pointers["mouse"] = event.pos
            elif t == pygame.MOUSEBUTTONUP and event.button == 1:
                self.pointers.pop("mouse", None)
        return actions

    def _taps(self, pos):
        if self.hit_power.collidepoint(pos):
            return ["power"]
        if self.hit_pause.collidepoint(pos):
            return ["pause"]
        return []

    @property
    def direction(self):
        """-1 (esquerda), 0 ou +1 (direita) conforme os dedos que estão nos botões."""
        if not self.enabled:
            return 0
        left = any(self.hit_left.collidepoint(p) for p in self.pointers.values())
        right = any(self.hit_right.collidepoint(p) for p in self.pointers.values())
        return int(right) - int(left)

    # ------------------------------------------------------------ desenho
    def _pressed(self, hit):
        return any(hit.collidepoint(p) for p in self.pointers.values())

    def _button(self, surface, rect, pressed, border=(190, 160, 255)):
        s = pygame.Surface(rect.size, pygame.SRCALPHA)
        fill = (150, 110, 240, 150) if pressed else (14, 8, 40, 120)
        pygame.draw.rect(s, fill, s.get_rect(), border_radius=28)
        pygame.draw.rect(s, border + (210,), s.get_rect(), width=4, border_radius=28)
        surface.blit(s, rect.topleft)

    def draw(self, surface, scene):
        if not self.enabled:
            return
        a = scene.assets
        # ---- setas
        for rect, hit, sign in ((self.left, self.hit_left, -1), (self.right, self.hit_right, 1)):
            pressed = self._pressed(hit)
            self._button(surface, rect, pressed)
            cx, cy = rect.center
            pts = [(cx + sign * 34, cy), (cx - sign * 26, cy - 40), (cx - sign * 26, cy + 40)]
            pygame.draw.polygon(surface, (255, 255, 255) if pressed else (225, 210, 255), pts)
        # ---- poder (mostra a recarga)
        ratio = scene.player.moonwalk_ratio
        ready = ratio >= 1.0
        pressed = self._pressed(self.hit_power)
        self._button(surface, self.power, pressed, border=settings.GOLD if ready else (140, 100, 230))
        fill = self.power.inflate(-24, -24)
        bar = pygame.Rect(fill.left, fill.bottom - 18, int(fill.width * ratio), 12)
        pygame.draw.rect(surface, (60, 40, 110), pygame.Rect(fill.left, fill.bottom - 18, fill.width, 12), border_radius=6)
        if ratio > 0:
            pygame.draw.rect(surface, settings.GOLD if ready else (140, 100, 230), bar, border_radius=6)
        name = scene.phase.get("power_name", "MOONWALK")
        a.draw_text(surface, name, 24 if len(name) < 10 else 20, settings.GOLD if ready else (200, 190, 240),
                    (self.power.centerx, self.power.top + 52), outline=2, outline_color=(10, 5, 25))
        a.draw_text(surface, "TOQUE!" if ready else "...", 22, settings.WHITE if ready else (160, 150, 200),
                    (self.power.centerx, self.power.top + 86), kind="secondary", outline=2, outline_color=(10, 5, 25))
        # ---- pausa
        self._button(surface, self.pause, self._pressed(self.hit_pause))
        px, py = self.pause.center
        for dx in (-9, 9):
            pygame.draw.rect(surface, (225, 210, 255), (px + dx - 5, py - 14, 10, 28), border_radius=3)
