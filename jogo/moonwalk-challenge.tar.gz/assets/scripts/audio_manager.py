"""
audio_manager.py
================
Controla música, efeitos e ambiente. Todo o resto do jogo só chama:

    audio.play("hit")            # efeito
    audio.play_music("stage_1")  # música de fundo (loop)

Volumes (todos de 0.0 a 1.0), ajustáveis em CONFIGURAÇÕES e salvos em
user_settings.json:
    master        -> volume geral (multiplica tudo)
    music_volumes -> UM volume para cada música (menu e cada fase)
    sfx_volume    -> efeitos sonoros (padrão bem mais baixo que a música)
"""
import pygame

from scripts import settings
from scripts.utils import load_user_settings, save_user_settings


def _clamp01(value, default):
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


class AudioManager:
    def __init__(self, assets):
        self.assets = assets
        self.current_music = None       # nome da música "desejada"
        self.current_ambience = None
        self.pending_music = None       # [nome, segundos restantes] (troca de fase em andamento)
        self.paused = False
        self.timed_sounds = []          # [canal, segundos restantes] (efeitos que serão cortados)
        self.enabled = bool(pygame.mixer.get_init())
        self.ambience_channel = None
        if self.enabled:
            pygame.mixer.set_num_channels(16)
            pygame.mixer.set_reserved(1)          # canal 0 fica só para o ambiente
            self.ambience_channel = pygame.mixer.Channel(0)

        # ---- preferências (valores padrão + o que estiver salvo)
        saved = load_user_settings()
        self.music_on = bool(saved.get("music_on", True))
        self.sfx_on = bool(saved.get("sfx_on", True))
        self.master = _clamp01(saved.get("master"), settings.DEFAULT_MASTER_VOLUME)
        self.sfx_volume = _clamp01(saved.get("sfx_volume"), settings.DEFAULT_SFX_VOLUME)
        self.music_volumes = {name: settings.DEFAULT_MUSIC_VOLUME for name in assets.music}
        for name, value in (saved.get("music_volumes") or {}).items():
            if name in self.music_volumes:
                self.music_volumes[name] = _clamp01(value, settings.DEFAULT_MUSIC_VOLUME)
        self._apply_volumes()

    # ------------------------------------------------------------ salvar
    def save(self):
        save_user_settings({
            "music_on": self.music_on, "sfx_on": self.sfx_on,
            "master": round(self.master, 2), "sfx_volume": round(self.sfx_volume, 2),
            "music_volumes": {k: round(v, 2) for k, v in self.music_volumes.items()},
        })

    # ------------------------------------------------------------ volumes
    def track_volume(self, name):
        return self.music_volumes.get(name, settings.DEFAULT_MUSIC_VOLUME)

    @property
    def music_volume(self):
        """Volume final da música que está tocando."""
        return self.track_volume(self.current_music) * self.master

    def _apply_volumes(self):
        if not self.enabled:
            return
        pygame.mixer.music.set_volume(self.music_volume)
        for name, sound in self.assets.sounds.items():
            factor = settings.AMBIENCE_FACTOR if name == "crowd" else 1.0
            sound.set_volume(self.sfx_volume * self.master * factor)

    def set_master(self, value):
        self.master = _clamp01(round(value, 2), self.master)
        self._apply_volumes()
        self.save()

    def set_sfx_volume(self, value):
        self.sfx_volume = _clamp01(round(value, 2), self.sfx_volume)
        self._apply_volumes()
        self.save()

    def set_music_volume(self, name, value):
        """Muda o volume de UMA música (ex.: 'stage_3'). Vale na hora se ela estiver tocando."""
        self.music_volumes[name] = _clamp01(round(value, 2), settings.DEFAULT_MUSIC_VOLUME)
        self._apply_volumes()
        self.save()

    # ------------------------------------------------------------ efeitos
    def play(self, name, max_seconds=None):
        """Toca um efeito. Com max_seconds, o som é cortado nesse tempo (com fade-out no final)."""
        if not (self.enabled and self.sfx_on):
            return
        sound = self.assets.sounds.get(name)
        if sound is None:
            return
        channel = sound.play()
        if max_seconds and channel is not None:
            self.timed_sounds.append([channel, max(max_seconds - settings.SOUND_FADEOUT, 0.05)])

    def toggle_sfx(self):
        self.sfx_on = not self.sfx_on
        if not self.sfx_on:
            self.timed_sounds.clear()
            pygame.mixer.stop()
        elif self.current_ambience:
            self.play_ambience(self.current_ambience)
        self.save()
        return self.sfx_on

    # ------------------------------------------------------------ ambiente
    def play_ambience(self, name):
        self.current_ambience = name
        if not (self.enabled and self.sfx_on):
            return
        sound = self.assets.sounds.get(name)
        if sound is not None and self.ambience_channel is not None:
            self.ambience_channel.play(sound, loops=-1)

    def stop_ambience(self):
        self.current_ambience = None
        if self.enabled and self.ambience_channel is not None:
            self.ambience_channel.stop()

    # ------------------------------------------------------------ música
    def play_music(self, name, fade_ms=600):
        if name == self.current_music and pygame.mixer.get_init() and pygame.mixer.music.get_busy():
            return
        self.current_music = name
        self._start_music(fade_ms)

    def _start_music(self, fade_ms=600):
        if not (self.enabled and self.music_on and self.current_music):
            return
        path = self.assets.music.get(self.current_music)
        if not path:
            return
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.music_volume)
            pygame.mixer.music.play(loops=-1, fade_ms=fade_ms)
        except pygame.error as err:
            print(f"[AVISO] Não foi possível tocar a música '{self.current_music}': {err}")

    def crossfade_to(self, name, fade_out_ms=800, delay=settings.PHASE_MUSIC_DELAY):
        """Troca de fase: a música atual TERMINA (fade out) e, depois de 'delay' segundos,
        começa a música da próxima fase."""
        self.current_music = name
        self.pending_music = [name, max(delay, fade_out_ms / 1000.0 + 0.2)]
        if self.enabled:
            pygame.mixer.music.fadeout(int(fade_out_ms))

    def update(self, dt):
        """Chamado todo quadro pelo Game: cuida da música que está esperando para entrar."""
        if self.paused:
            return
        for item in self.timed_sounds[:]:
            item[1] -= dt
            if item[1] <= 0:
                self.timed_sounds.remove(item)
                item[0].fadeout(int(settings.SOUND_FADEOUT * 1000))
        if self.pending_music is None:
            return
        self.pending_music[1] -= dt
        if self.pending_music[1] <= 0:
            self.pending_music = None
            self._start_music(fade_ms=500)

    def stop_music(self, fade_ms=0):
        self.pending_music = None
        self.current_music = None
        if self.enabled:
            if fade_ms:
                pygame.mixer.music.fadeout(fade_ms)
            else:
                pygame.mixer.music.stop()

    def toggle_music(self):
        self.music_on = not self.music_on
        if self.enabled:
            if self.music_on:
                self._start_music(300)
            else:
                pygame.mixer.music.stop()
        self.save()
        return self.music_on

    # ------------------------------------------------------------ pausa
    def pause_all(self):
        self.paused = True
        if self.enabled:
            pygame.mixer.music.pause()
            pygame.mixer.pause()

    def resume_all(self):
        self.paused = False
        if self.enabled:
            pygame.mixer.music.unpause()
            pygame.mixer.unpause()

    def stop_all(self):
        """Para tudo (usado ao sair de uma partida)."""
        self.pending_music = None
        self.timed_sounds.clear()
        self.paused = False
        self.current_music = None
        self.current_ambience = None
        if self.enabled:
            pygame.mixer.music.unpause()
            pygame.mixer.music.stop()
            pygame.mixer.unpause()
            pygame.mixer.stop()
