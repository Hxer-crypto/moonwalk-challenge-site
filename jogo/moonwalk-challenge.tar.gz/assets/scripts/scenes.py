"""
scenes.py
=========
Sistema de cenas. Cada tela do jogo é uma classe com 4 métodos:

    handle_event(event)  -> reage a teclado/mouse
    update(dt)           -> atualiza a lógica (dt = segundos desde o último frame)
    draw(screen)         -> desenha na tela
    on_enter/on_exit     -> chamados quando a cena entra/sai

Cenas: MenuScene, HowToPlayScene, SettingsScene, GameScene, PauseScene,
       GameOverScene, VictoryScene.
A troca de cena é feita por  self.game.change_scene(NovaCena(self.game)).
"""
import math
import random

import pygame

from scripts import settings
from scripts.background import ParallaxBackground
from scripts.button import Button, ButtonMenu, Slider
from scripts.hud import HUD
from scripts.particles import FloatingText, ParticleSystem, SmokeLayer
from scripts.player import Player
from scripts.spawner import Spawner
from scripts.touch import TouchControls
from scripts.utils import blit_alpha, clamp, ease_out_back, lerp, tint

W, H = settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT
PALETTE = [(255, 214, 80), (150, 90, 230), (90, 170, 255), (255, 255, 255), (255, 120, 190)]


def dim_overlay(alpha):
    surf = pygame.Surface((W, H), pygame.SRCALPHA)
    surf.fill((4, 2, 14, alpha))
    return surf


def draw_keycap(surface, assets, rect, label=None, arrow=None):
    """Desenha uma tecla (keycap). arrow = 'left' ou 'right' desenha uma seta."""
    pygame.draw.rect(surface, (30, 24, 50), rect.move(0, 4), border_radius=9)
    pygame.draw.rect(surface, (228, 224, 244), rect, border_radius=9)
    pygame.draw.rect(surface, (120, 110, 170), rect, width=2, border_radius=9)
    if arrow:
        cx, cy = rect.center
        d = 1 if arrow == "right" else -1
        pygame.draw.polygon(surface, (40, 30, 80), [(cx - 8 * d, cy - 10), (cx - 8 * d, cy + 10), (cx + 10 * d, cy)])
    else:
        assets.draw_text(surface, label, 22, (40, 30, 80), rect.center)


class Scene:
    def __init__(self, game):
        self.game = game
        self.assets = game.assets
        self.audio = game.audio

    def on_enter(self):
        pass

    def on_exit(self):
        pass

    def handle_event(self, event):
        pass

    def update(self, dt):
        pass

    def draw(self, screen):
        pass


# =====================================================================
#  MENU PRINCIPAL
# =====================================================================
class MenuScene(Scene):
    def __init__(self, game):
        super().__init__(game)
        self.bg = ParallaxBackground(self.assets, "menu", beams=4)
        self.smoke = SmokeLayer(self.assets, count=8, level=0.9)
        self.particles = ParticleSystem()
        self.player = Player(self.assets, x=1000, floor_y=700, scale=2.2, skin=settings.PHASES[0]["skin"])
        self.player.play("moonwalk")
        self.skin_index = 0
        self.menu_skins = []                           # um figurino de cada fase (sem repetir)
        for _ph in settings.PHASES:
            if _ph["skin"] not in self.menu_skins:
                self.menu_skins.append(_ph["skin"])
        self.skin_timer = 0.0
        self.time = 0.0
        self.spark_timer = 0.0
        cx = 350
        a, au = self.assets, self.audio
        self.menu = ButtonMenu([
            Button("JOGAR", (cx, 372), self.on_play, a, au),
            Button("COMO JOGAR", (cx, 448), self.on_how_to, a, au),
            Button("CONFIGURAÇÕES", (cx, 524), self.on_settings, a, au),
            Button("SAIR", (cx, 600), self.on_quit, a, au),
        ])
        self.glow = tint(pygame.transform.smoothscale(self.assets.images["glow"], (620, 620)), (110, 70, 210))

    def on_enter(self):
        self.audio.stop_ambience()
        self.audio.play_music("menu_theme")

    # ---- ações dos botões
    def on_play(self):
        self.game.change_scene(GameScene(self.game))

    def on_how_to(self):
        self.game.change_scene(HowToPlayScene(self.game))

    def on_settings(self):
        self.game.change_scene(SettingsScene(self.game))

    def on_quit(self):
        self.game.change_scene(None)

    def handle_event(self, event):
        self.menu.handle_event(event)

    def update(self, dt):
        self.time += dt
        self.bg.update(dt)
        self.smoke.update(dt)
        self.player.tick_animation(dt)
        self.skin_timer += dt                       # troca de figurino a cada 5 s (mostra todas as fases)
        if self.skin_timer >= 5.0:
            self.skin_timer = 0.0
            self.skin_index = (self.skin_index + 1) % len(self.menu_skins)
            self.player.set_skin(self.menu_skins[self.skin_index])
            self.particles.emit(1000, 520, 28, PALETTE, speed=(80, 300), shape="star", life=(0.5, 1.1))
        self.spark_timer -= dt
        if self.spark_timer <= 0:
            self.spark_timer = 0.07
            self.particles.emit(random.uniform(0, W), random.uniform(300, 700), 1, PALETTE, speed=(10, 40),
                                life=(1.0, 2.0), size=(2, 5), shape="star", angle=(250, 290))
        self.particles.update(dt)

    def draw(self, screen):
        self.bg.draw_back(screen)
        screen.blit(self.glow, self.glow.get_rect(center=(1000, 470)), special_flags=pygame.BLEND_ADD)
        self.smoke.draw(screen)
        self.player.draw(screen)
        self.particles.draw(screen)
        self.bg.draw_front(screen)

        # ---- título
        bob = math.sin(self.time * 2.0) * 5
        a = self.assets
        a.draw_text(screen, "MICHAEL JACKSON", 100, settings.WHITE, (W // 2, 92 + bob), outline=7,
                    outline_color=(85, 35, 160))
        pulse = 0.85 + 0.15 * math.sin(self.time * 4)
        gold = tuple(int(c * pulse) for c in settings.GOLD)
        a.draw_text(screen, "MOONWALK CHALLENGE", 58, gold, (W // 2, 178 + bob), outline=5,
                    outline_color=(70, 30, 0))
        self.menu.draw(screen)
        a.draw_text(screen, f"RECORDE: {self.game.high_score}", 26, (200, 185, 255), (350, 668),
                    kind="secondary", outline=2, outline_color=(10, 5, 25))
        if self.assets.missing:
            a.draw_text(screen, "Assets faltando! Rode: python tools/generate_assets.py", 20, settings.RED,
                        (12, 8), "topleft", kind="secondary", outline=2)


# =====================================================================
#  COMO JOGAR
# =====================================================================
class HowToPlayScene(Scene):
    def __init__(self, game):
        super().__init__(game)
        self.bg = ParallaxBackground(self.assets, "menu", beams=3)
        self.dim = dim_overlay(170)
        self.time = 0.0
        self.menu = ButtonMenu([Button("VOLTAR", (W // 2, 650), self.back, self.assets, self.audio)])

    def back(self):
        self.game.change_scene(MenuScene(self.game))

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            self.audio.play("button")
            self.back()
            return
        self.menu.handle_event(event)

    def update(self, dt):
        self.time += dt
        self.bg.update(dt)

    def draw(self, screen):
        a = self.assets
        self.bg.draw_back(screen)
        screen.blit(self.dim, (0, 0))
        a.draw_text(screen, "COMO JOGAR", 70, settings.GOLD, (W // 2, 62), outline=5, outline_color=(70, 30, 0))
        panel = pygame.Rect(0, 0, 780, 470)
        panel.center = (W // 2, 350)
        pygame.draw.rect(screen, (14, 8, 38), panel, border_radius=22)
        pygame.draw.rect(screen, (150, 100, 240), panel, width=3, border_radius=22)

        x_key, x_text = panel.left + 130, panel.left + 250
        y = panel.top + 46
        step = 60

        def row(y, text, color=settings.WHITE):
            a.draw_text(screen, text, 28, color, (x_text, y), "midleft", kind="secondary")

        draw_keycap(screen, a, pygame.Rect(x_key - 62, y - 22, 54, 44), arrow="left")
        draw_keycap(screen, a, pygame.Rect(x_key + 6, y - 22, 54, 44), arrow="right")
        row(y, "Movimentar o personagem")
        y += step
        draw_keycap(screen, a, pygame.Rect(x_key - 62, y - 22, 122, 44), label="ESPAÇO")
        row(y, "Moonwalk! (pontos em dobro)", settings.GOLD)
        y += step
        for key, txt, color in (("star", "+10 pontos", (255, 240, 150)),
                                ("note", "+20 pontos", (140, 200, 255)),
                                ("golden_star", "+50 pontos", settings.GOLD)):
            img = pygame.transform.smoothscale(a.images[key], (48, 48))
            screen.blit(img, img.get_rect(center=(x_key - 2, y)))
            row(y, txt, color)
            y += step
        img = pygame.transform.smoothscale(a.images["icon_hit"], (48, 48))
        screen.blit(img, img.get_rect(center=(x_key - 2, y)))
        row(y, "Obstáculo: você perde uma vida", (255, 130, 140))
        y += step
        draw_keycap(screen, a, pygame.Rect(x_key - 62, y - 22, 122, 44), label="ESC")
        row(y, "Pausar o jogo")
        a.draw_text(screen, "No celular: use os botões na tela (setas, poder e pausa)", 22, (200, 185, 255),
                    (W // 2, 612), kind="secondary")
        self.menu.draw(screen)


# =====================================================================
#  CONFIGURAÇÕES (com abas)
# =====================================================================
class SettingsScene(Scene):
    """Aba GERAL: música/efeitos on-off, volume geral, volume dos efeitos, música do menu.
    Aba MÚSICA POR FASE: um volume para a música de cada fase (toca a música ao mexer)."""

    def __init__(self, game, tab=0):
        super().__init__(game)
        self.bg = ParallaxBackground(self.assets, "menu", beams=3)
        self.dim = dim_overlay(175)
        self.tab = tab
        a, au = self.assets, self.audio
        cx = W // 2

        # ---- botões das abas
        self.tab_buttons = [
            Button("GERAL", (cx - 190, 150), lambda: self.set_tab(0), a, au, size=(360, 52), font_size=26),
            Button("MÚSICA POR FASE", (cx + 190, 150), lambda: self.set_tab(1), a, au, size=(360, 52),
                   font_size=26),
        ]

        # ---- aba 0: GERAL
        self.music_btn = Button(self._music_text(), (cx, 240), self.toggle_music, a, au, size=(760, 56))
        self.sfx_btn = Button(self._sfx_text(), (cx, 306), self.toggle_sfx, a, au, size=(760, 56))
        self.master_slider = Slider("VOLUME GERAL", (cx, 372), au.master, au.set_master, a, au, label_w=350, font_size=24)
        self.sfx_slider = Slider("VOLUME DOS EFEITOS", (cx, 438), au.sfx_volume, au.set_sfx_volume, a, au,
                                 label_w=350, font_size=24)
        self.menu_slider = Slider("MÚSICA DO MENU", (cx, 504), au.track_volume("menu_theme"),
                                  lambda v: au.set_music_volume("menu_theme", v), a, au, label_w=350, font_size=24)
        back0 = Button("VOLTAR", (cx, 596), self.back, a, au, size=(760, 56))
        menu0 = ButtonMenu([self.music_btn, self.sfx_btn, self.master_slider, self.sfx_slider,
                            self.menu_slider, back0])

        # ---- aba 1: MÚSICA POR FASE (um slider por fase)
        self.phase_sliders = []
        per_col = (len(settings.PHASES) + 1) // 2           # 2 colunas para caber 10 fases na tela
        for i, ph in enumerate(settings.PHASES):
            track = ph["music"]
            col, row = divmod(i, per_col)
            sx = cx - 322 + col * 644
            sl = Slider(f"{i + 1} - {ph['title']}", (sx, 240 + row * 62), au.track_volume(track),
                        lambda v, t=track: self.on_phase_volume(t, v), a, au, size=(630, 56), label_w=340,
                        font_size=17, steps=20)
            self.phase_sliders.append(sl)
        back1 = Button("VOLTAR", (cx, 596), self.back, a, au, size=(760, 56))
        menu1 = ButtonMenu(self.phase_sliders + [back1])
        self.menus = [menu0, menu1]
        self._sync_tabs()

    # ---- textos / ações
    def _music_text(self):
        return "MÚSICA: " + ("ON" if self.audio.music_on else "OFF")

    def _sfx_text(self):
        return "EFEITOS: " + ("ON" if self.audio.sfx_on else "OFF")

    def _sync_tabs(self):
        for i, b in enumerate(self.tab_buttons):
            b.selected = (i == self.tab)

    def set_tab(self, tab):
        if tab == self.tab:
            return
        self.tab = tab
        self._sync_tabs()
        if tab == 0:                                    # saiu da aba de músicas: volta a música do menu
            self.audio.play_music("menu_theme")

    def on_phase_volume(self, track, value):
        self.audio.set_music_volume(track, value)
        self.audio.play_music(track)                    # prévia: toca a música da fase para você ouvir

    def toggle_music(self):
        self.audio.toggle_music()
        self.music_btn.set_text(self._music_text())

    def toggle_sfx(self):
        self.audio.toggle_sfx()
        self.sfx_btn.set_text(self._sfx_text())
        if self.audio.sfx_on:
            self.audio.play("collect_note")

    def back(self):
        self.game.change_scene(MenuScene(self.game))

    # ---- cena
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.back()
                return
            if event.key == pygame.K_TAB:
                self.set_tab((self.tab + 1) % 2)
                return
        for b in self.tab_buttons:
            b.handle_mouse(event)
        self.menus[self.tab].handle_event(event)

    def update(self, dt):
        self.bg.update(dt)

    def draw(self, screen):
        a = self.assets
        self.bg.draw_back(screen)
        screen.blit(self.dim, (0, 0))
        a.draw_text(screen, "CONFIGURAÇÕES", 62, settings.GOLD, (W // 2, 70), outline=5, outline_color=(70, 30, 0))
        for b in self.tab_buttons:
            b.draw(screen)
        self.menus[self.tab].draw(screen)
        hint = ("Mexa em uma barra para OUVIR a música daquela fase. TAB troca de aba." if self.tab == 1 else
                "Setas ← → ajustam o volume. TAB troca de aba. ESC volta.")
        a.draw_text(screen, hint, 22, (190, 175, 240), (W // 2, 664), kind="secondary")


# =====================================================================
#  JOGO
# =====================================================================
class GameScene(Scene):
    BANNER_TIME = 2.2       # tempo do letreiro "FASE X!"
    END_TIME = 1.7          # tempo entre o fim da partida e a tela final

    def __init__(self, game):
        super().__init__(game)
        self.world = pygame.Surface((W, H)).convert()     # desenhamos aqui e depois copiamos (treme-tela)
        self.overlay = pygame.Surface((W, H))
        self.band = pygame.Surface((W, 214), pygame.SRCALPHA)
        self.band.fill((4, 2, 14, 175))
        self.hud = HUD(self.assets)
        self.touch = TouchControls(game)   # botões de toque (celular)
        self.particles = ParticleSystem()
        self.floaters = []
        self.obstacles = pygame.sprite.Group()
        self.collectibles = pygame.sprite.Group()
        self.player = Player(self.assets, skin=settings.PHASES[0]["skin"], boost=settings.PIC_SIZE_BOOST)
        self.spawner = Spawner(self.assets, self.obstacles, self.collectibles)
        self.smoke = SmokeLayer(self.assets)
        self.backgrounds = {}
        self.spot = tint(pygame.transform.smoothscale(self.assets.images["glow"], (380, 120)), (130, 95, 220))
        self.input_override = None      # usado nos testes automáticos
        self._started = False
        self.reset()

    # ------------------------------------------------------------ reinício
    def reset(self):
        """Zera TUDO (usado ao começar/reiniciar a partida)."""
        self.score = 0
        self.lives = settings.INITIAL_LIVES
        self.phase_index = 0
        self.phase = settings.PHASES[0]
        self.state = "playing"          # playing | dying | winning | finished
        self.phase_time = 0.0
        self.banner_timer = 0.0
        self.end_timer = 0.0
        self.survive_timer = 0.0
        self.trail_timer = 0.0
        self.shake_timer = 0.0
        self.red_flash = 0.0
        self.gold_flash = 0.0
        self.white_flash = 0.0
        self.is_new_record = False
        self.obstacles.empty()
        self.collectibles.empty()
        self.particles.clear()
        self.floaters.clear()
        self.player.set_skin(self.phase["skin"])
        self.player.reset()
        self.spawner.reset()
        self.background = self._get_background(self.phase)

    def _get_background(self, phase):
        """Cria (uma vez) o cenário da fase, com os raios de luz definidos em settings.PHASES."""
        name = phase["background"]
        if name not in self.backgrounds:
            self.backgrounds[name] = ParallaxBackground(
                self.assets, name, beams=phase["bg_beams"], beam_colors=phase["bg_colors"],
                crowd_sway=phase["crowd_sway"])
        return self.backgrounds[name]

    def on_enter(self):
        if not self._started:
            self._started = True
            self._begin_phase(0, first=True)

    # ------------------------------------------------------------ fases
    def _begin_phase(self, index, first=False):
        self.phase_index = index
        self.phase = settings.PHASES[index]
        self.phase_time = 0.0
        self.banner_timer = self.BANNER_TIME
        self.background = self._get_background(self.phase)
        self.player.set_skin(self.phase["skin"])          # troca de figurino a cada fase
        self.player.set_power(self.phase)                 # e de poder especial (moonwalk / inclinação)
        self.smoke.set_level(self.phase["smoke"])
        # limpa os obstáculos com uma explosão de brilho (a transição fica justa)
        for o in list(self.obstacles):
            self.particles.emit(o.rect.centerx, o.rect.centery, 10, PALETTE, shape="star", life=(0.5, 1.0))
            o.kill()
        self.spawner.reset()
        if first:
            self.audio.play_music(self.phase["music"], fade_ms=800)
            self.audio.play_ambience("crowd")
        else:
            # a música da fase anterior TERMINA, toca o som de troca de fase (3,5 s)
            # e depois entra a música da nova fase
            self.audio.crossfade_to(self.phase["music"], fade_out_ms=800)
            self.audio.play("phase_change", max_seconds=settings.PHASE_CHANGE_SOUND_TIME)
            self.white_flash = 0.5
            self.particles.emit(self.player.x, self.player.rect.centery, 30, PALETTE, speed=(80, 320),
                                shape="star", life=(0.6, 1.2))
            for _ in range(3):
                self.particles.emit(random.uniform(200, W - 200), random.uniform(120, 300), 24, PALETTE,
                                    speed=(80, 300), shape="star", life=(0.6, 1.3), gravity=150)

    def _fall_speed(self):
        ramp = min(1.0, self.phase_time / settings.RAMP_SECONDS)
        return settings.OBSTACLE_SPEED * self.phase["speed_mult"] * (1.0 + settings.RAMP_SPEED_BONUS * ramp)

    # ------------------------------------------------------------ entrada
    def pause_game(self):
        self.touch.reset()
        self.audio.pause_all()
        self.game.change_scene(PauseScene(self.game, self, self.game.screen.copy()), fade=False)

    def handle_event(self, event):
        for action in self.touch.handle_event(event):         # botões de toque
            if self.state == "playing":
                if action == "power":
                    self.start_moonwalk()
                elif action == "pause":
                    self.pause_game()
                    return
        if event.type != pygame.KEYDOWN:
            return
        if event.key in (pygame.K_ESCAPE, pygame.K_p) and self.state == "playing":
            self.pause_game()
        elif event.key == pygame.K_SPACE and self.state == "playing":
            self.start_moonwalk()

    def _direction(self):
        if self.input_override is not None:
            return self.input_override
        keys = pygame.key.get_pressed()
        d = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
        return d or self.touch.direction

    def start_moonwalk(self):
        """ESPAÇO: ativa o poder da fase (moonwalk ou inclinação do Smooth Criminal)."""
        if self.player.start_power():
            ph = self.phase
            # o SOM do poder tem duração própria (power_sound_time), separada da duração do poder
            self.audio.play(ph.get("power_sound", "moonwalk"),
                            max_seconds=ph.get("power_sound_time", settings.MOONWALK_SOUND_TIME))
            bonus = settings.LEAN_BONUS if self.player.power_kind == "lean" else settings.MOONWALK_BONUS
            self.score += bonus
            self.floaters.append(FloatingText(f"{ph.get('power_name', 'MOONWALK')}! +{bonus}", self.player.x,
                                              self.player.rect.top - 20, settings.GOLD, size=32, life=1.2))
            self.gold_flash = 0.4
            self.particles.emit(self.player.x, self.player.rect.bottom - 10, 24, [settings.GOLD, (255, 255, 255)],
                                speed=(80, 260), shape="star", life=(0.5, 1.0), angle=(200, 340))

    # ------------------------------------------------------------ pontos
    def collect(self, item):
        mult = settings.MOONWALK_SCORE_MULT if self.player.moonwalking else 1
        pts = item.points * mult
        self.score += pts
        self.audio.play(item.sound)
        self.particles.emit(item.rect.centerx, item.rect.centery, 16, item.particle_colors,
                            speed=(70, 260), shape="star", life=(0.4, 0.9), size=(3, 6))
        color = settings.GOLD if item.kind == "golden_star" else settings.WHITE
        self.floaters.append(FloatingText(f"+{pts}", item.rect.centerx, item.rect.top, color,
                                          size=34 if item.kind == "golden_star" else 28))

    def hit_by(self, obstacle):
        if not self.player.hurt():
            return
        self.lives -= 1
        self.audio.play("hit")
        self.particles.emit(obstacle.rect.centerx, obstacle.rect.centery, 30, [(255, 90, 60), (255, 190, 60), (255, 255, 255)],
                            speed=(100, 380), shape="square", life=(0.4, 0.9), gravity=500)
        self.shake_timer = 0.35
        self.red_flash = 0.35
        obstacle.kill()
        if self.lives <= 0:
            self._lose()

    def _lose(self):
        self.state = "dying"
        self.end_timer = self.END_TIME
        self.player.hit_timer = self.END_TIME
        self.player.invulnerable_timer = 0
        self.is_new_record = self.game.update_high_score(self.score)
        self.audio.stop_music(fade_ms=400)
        self.audio.stop_ambience()
        self.audio.play("game_over")

    def _win(self):
        self.state = "winning"
        self.end_timer = self.END_TIME
        self.player.celebrate()
        self.is_new_record = self.game.update_high_score(self.score)
        self.audio.stop_music(fade_ms=300)
        self.audio.stop_ambience()
        self.audio.play("victory")
        self.white_flash = 0.5
        for _ in range(4):
            self.particles.emit(random.uniform(150, W - 150), random.uniform(100, 350), 26, PALETTE,
                                speed=(90, 330), shape="star", life=(0.7, 1.4), gravity=160)

    # ------------------------------------------------------------ atualização
    def update(self, dt):
        if self.state == "finished":
            return
        self.background.update(dt)
        self.smoke.update(dt)

        playing = self.state == "playing"
        self.player.update(dt, self._direction() if playing else 0)

        # timers de efeitos
        self.shake_timer = max(0.0, self.shake_timer - dt)
        self.red_flash = max(0.0, self.red_flash - dt)
        self.gold_flash = max(0.0, self.gold_flash - dt)
        self.white_flash = max(0.0, self.white_flash - dt)
        if self.banner_timer > 0:
            self.banner_timer -= dt

        # spawn (não spawna durante o letreiro da fase)
        if playing and self.banner_timer <= 0:
            self.phase_time += dt
            ramp = min(1.0, self.phase_time / settings.RAMP_SECONDS)
            self.spawner.update(dt, self.phase, ramp)

        # movimento + limpeza dos objetos
        speed = self._fall_speed()
        for o in list(self.obstacles):
            o.update(dt, speed)
            if o.is_offscreen():
                self.particles.emit(o.rect.centerx, o.rect.bottom, 6, [(180, 160, 220)], speed=(30, 120),
                                    life=(0.2, 0.5), size=(2, 4), angle=(200, 340))
                o.kill()
        for c in list(self.collectibles):
            c.update(dt, speed)
            if c.is_offscreen():
                c.kill()
        # ÍMÃ do Smooth Criminal: enquanto inclinado, os itens de pontos voam até o personagem
        if playing and self.player.leaning:
            pc = self.player.rect.center
            for c in self.collectibles:
                if math.hypot(c.x - pc[0], c.y - pc[1]) <= settings.LEAN_MAGNET_RADIUS:
                    c.attract(dt, pc, settings.LEAN_MAGNET_SPEED)
            if random.random() < 0.5:
                self.particles.emit(pc[0], pc[1], 2, [(150, 200, 255), (255, 255, 255)], speed=(40, 140),
                                    shape="star", life=(0.3, 0.6), size=(2, 4))

        if playing:
            # PLAYER x OBSTACLE
            if self.banner_timer <= 0 and not self.player.invulnerable and not self.player.shielded:
                hit = pygame.sprite.spritecollideany(self.player, self.obstacles)
                if hit:
                    self.hit_by(hit)
            # PLAYER x COLLECTIBLE
            if self.state == "playing":
                for item in pygame.sprite.spritecollide(self.player, self.collectibles, True):
                    self.collect(item)
            # pontos por sobreviver
            self.survive_timer += dt
            while self.survive_timer >= settings.SURVIVE_INTERVAL:
                self.survive_timer -= settings.SURVIVE_INTERVAL
                self.score += settings.SURVIVE_POINTS
            # rastro de estrelinhas do moonwalk
            if self.player.moonwalking:
                self.trail_timer -= dt
                if self.trail_timer <= 0:
                    self.trail_timer = 0.04
                    self.particles.emit(self.player.x, self.player.rect.bottom - 6, 2,
                                        [settings.GOLD, (255, 255, 255), settings.BLUE], speed=(20, 90),
                                        shape="star", life=(0.3, 0.7), size=(2, 5), angle=(180, 360))
            # meta da fase
            if self.state == "playing" and self.score >= self.phase["goal"]:
                if self.phase_index == len(settings.PHASES) - 1:
                    self._win()
                else:
                    self._begin_phase(self.phase_index + 1)
        else:
            # "dying" / "winning": espera um pouco e vai para a tela final
            self.end_timer -= dt
            if self.state == "winning" and random.random() < 0.15:
                self.particles.emit(random.uniform(150, W - 150), random.uniform(100, 350), 18, PALETTE,
                                    speed=(90, 300), shape="star", life=(0.6, 1.2), gravity=160)
            if self.end_timer <= 0:
                won = self.state == "winning"
                self.state = "finished"
                if won:
                    self.game.change_scene(VictoryScene(self.game, self.score, self.is_new_record, self.player.skin))
                else:
                    self.game.change_scene(GameOverScene(self.game, self.score, self.is_new_record, self.player.skin))

        self.particles.update(dt)
        for f in self.floaters:
            f.update(dt)
        self.floaters = [f for f in self.floaters if f.alive]

    # ------------------------------------------------------------ desenho
    def draw(self, screen):
        w = self.world
        self.background.draw_back(w)
        self.smoke.draw(w)
        # foco de luz no palco, embaixo do personagem
        w.blit(self.spot, self.spot.get_rect(center=(round(self.player.x), self.player.floor_y + 6)),
               special_flags=pygame.BLEND_ADD)
        for c in self.collectibles:
            c.draw(w)
        for o in self.obstacles:
            o.draw(w)
        self.player.draw(w)
        self.particles.draw(w)
        for f in self.floaters:
            f.draw(w, self.assets)
        self.background.draw_front(w)

        # flashes de tela
        for timer, color, strength, total in ((self.red_flash, (200, 20, 40), 110, 0.35),
                                              (self.gold_flash, (255, 200, 60), 70, 0.4),
                                              (self.white_flash, (255, 255, 255), 130, 0.5)):
            if timer > 0:
                self.overlay.fill(color)
                self.overlay.set_alpha(int(strength * timer / total))
                w.blit(self.overlay, (0, 0))

        # treme-tela ao tomar dano
        if self.shake_timer > 0:
            k = self.shake_timer / 0.35
            ox, oy = int(random.uniform(-9, 9) * k), int(random.uniform(-7, 7) * k)
            screen.fill((0, 0, 0))
            screen.blit(w, (ox, oy))
        else:
            screen.blit(w, (0, 0))

        self.hud.draw(screen, self)
        if self.banner_timer > 0:
            self._draw_banner(screen)
        self.touch.draw(screen, self)

    def _draw_banner(self, screen):
        p = 1.0 - self.banner_timer / self.BANNER_TIME          # 0 -> 1
        alpha = int(255 * clamp(min(p / 0.12, (1 - p) / 0.2), 0, 1))
        cy = int(H * 0.40)
        band = self.band.copy()
        band.set_alpha(alpha)
        screen.blit(band, (0, cy - 107))
        a = self.assets
        big = a.render_text(f"{self.phase['name']}!", 92, settings.GOLD, outline=6, outline_color=(70, 30, 0))
        scale = 0.6 + 0.4 * ease_out_back(min(1.0, p / 0.25))
        big = pygame.transform.rotozoom(big, 0, scale)
        blit_alpha(screen, big, big.get_rect(center=(W // 2, cy - 48)).topleft, alpha)
        song = a.render_text(self.phase["title"], 52, settings.WHITE, outline=4, outline_color=(40, 20, 90))
        blit_alpha(screen, song, song.get_rect(center=(W // 2, cy + 16)).topleft, alpha)
        sub = a.render_text(self.phase["subtitle"], 26, (215, 200, 255), kind="secondary", outline=2,
                            outline_color=(20, 10, 50))
        blit_alpha(screen, sub, sub.get_rect(center=(W // 2, cy + 54)).topleft, alpha)
        if int(p * 6) % 2 == 0:
            ready = a.render_text("PREPARE-SE!", 32, settings.BLUE, outline=3, outline_color=(10, 20, 60))
            blit_alpha(screen, ready, ready.get_rect(center=(W // 2, cy + 90)).topleft, alpha)


# =====================================================================
#  PAUSA
# =====================================================================
class PauseScene(Scene):
    def __init__(self, game, game_scene, snapshot):
        super().__init__(game)
        self.game_scene = game_scene
        self.snapshot = snapshot           # foto da tela no momento da pausa
        self.dim = dim_overlay(150)
        cx = W // 2
        a, au = self.assets, self.audio
        self.menu = ButtonMenu([
            Button("CONTINUAR", (cx, 330), self.resume, a, au),
            Button("MENU", (cx, 410), self.to_menu, a, au),
            Button("SAIR", (cx, 490), self.quit, a, au),
        ])

    def resume(self):
        self.audio.resume_all()
        self.game.change_scene(self.game_scene, fade=False)

    def to_menu(self):
        self.audio.stop_all()
        self.game.change_scene(MenuScene(self.game))

    def quit(self):
        self.audio.stop_all()
        self.game.change_scene(None)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_p):
            self.resume()
            return
        self.menu.handle_event(event)

    def draw(self, screen):
        screen.blit(self.snapshot, (0, 0))
        screen.blit(self.dim, (0, 0))
        self.assets.draw_text(screen, "PAUSADO", 96, settings.GOLD, (W // 2, 205), outline=6,
                              outline_color=(70, 30, 0))
        self.menu.draw(screen)


# =====================================================================
#  GAME OVER
# =====================================================================
class GameOverScene(Scene):
    def __init__(self, game, score, is_new_record, skin=None):
        super().__init__(game)
        self.score = score
        self.is_new_record = is_new_record
        self.bg = ParallaxBackground(self.assets, settings.PHASES[0]["background"])
        self.smoke = SmokeLayer(self.assets, level=0.5)
        self.dim = dim_overlay(160)
        self.player = Player(self.assets, x=1040, floor_y=690, scale=1.8, skin=skin)
        self.player.play("hit")
        self.t = 0.0
        cx = 520
        a, au = self.assets, self.audio
        self.menu = ButtonMenu([
            Button("JOGAR NOVAMENTE", (cx, 520), self.again, a, au, size=(440, 62)),
            Button("MENU", (cx, 600), self.to_menu, a, au, size=(440, 62)),
        ])

    def on_enter(self):
        self.audio.stop_ambience()

    def again(self):
        self.game.change_scene(GameScene(self.game))

    def to_menu(self):
        self.game.change_scene(MenuScene(self.game))

    def handle_event(self, event):
        self.menu.handle_event(event)

    def update(self, dt):
        self.t += dt
        self.bg.update(dt)
        self.smoke.update(dt)
        self.player.tick_animation(dt)

    def draw(self, screen):
        a = self.assets
        self.bg.draw_back(screen)
        self.smoke.draw(screen)
        screen.blit(self.dim, (0, 0))
        self.player.draw(screen)
        self.bg.draw_front(screen)
        drop = ease_out_back(self.t / 0.9)
        y = lerp(-120, 150, drop)
        shake = math.sin(self.t * 60) * 3 if 0.9 < self.t < 1.3 else 0
        a.draw_text(screen, "GAME OVER", 132, (235, 70, 90), (520 + shake, y), outline=8, outline_color=(60, 5, 20))
        fade = clamp((self.t - 0.7) / 0.5, 0, 1) * 255
        for text, size, color, yy in ((f"SCORE: {self.score}", 60, settings.WHITE, 275),
                                      (f"HIGH SCORE: {self.game.high_score}", 42, settings.GOLD, 340)):
            img = a.render_text(text, size, color, outline=3, outline_color=(20, 10, 40))
            blit_alpha(screen, img, img.get_rect(center=(520, yy)).topleft, fade)
        if self.is_new_record and self.t > 1.0:
            s = 1.0 + 0.08 * math.sin(self.t * 8)
            img = pygame.transform.rotozoom(
                a.render_text("NOVO RECORDE!", 44, settings.GOLD, outline=3, outline_color=(70, 30, 0)), 0, s)
            screen.blit(img, img.get_rect(center=(520, 415)))
        self.menu.draw(screen)


# =====================================================================
#  VITÓRIA
# =====================================================================
class VictoryScene(Scene):
    def __init__(self, game, score, is_new_record, skin=None):
        super().__init__(game)
        self.score = score
        self.is_new_record = is_new_record
        self.bg = ParallaxBackground(self.assets, "menu", beams=6,
                                     beam_colors=[(255, 100, 200), (110, 200, 255), (255, 220, 90), (170, 110, 255)])
        self.smoke = SmokeLayer(self.assets, level=1.0)
        self.particles = ParticleSystem()
        self.player = Player(self.assets, x=1050, floor_y=690, scale=1.8, skin=skin)
        self.player.celebrate()
        self.glow = tint(pygame.transform.smoothscale(self.assets.images["glow"], (560, 560)), (255, 190, 80))
        self.t = 0.0
        self.firework_timer = 0.0
        cx = 520
        a, au = self.assets, self.audio
        self.menu = ButtonMenu([
            Button("JOGAR NOVAMENTE", (cx, 560), self.again, a, au, size=(440, 62)),
            Button("MENU", (cx, 636), self.to_menu, a, au, size=(440, 62)),
        ])

    def on_enter(self):
        self.audio.stop_ambience()

    def again(self):
        self.audio.stop_all()
        self.game.change_scene(GameScene(self.game))

    def to_menu(self):
        self.audio.stop_all()
        self.game.change_scene(MenuScene(self.game))

    def handle_event(self, event):
        self.menu.handle_event(event)

    def update(self, dt):
        self.t += dt
        self.bg.update(dt)
        self.smoke.update(dt)
        self.player.tick_animation(dt)
        self.firework_timer -= dt
        if self.firework_timer <= 0:
            self.firework_timer = 0.5
            self.particles.emit(random.uniform(120, W - 120), random.uniform(80, 330), 34, PALETTE,
                                speed=(90, 320), shape="star", life=(0.6, 1.3), gravity=180)
        # confete caindo
        self.particles.emit(random.uniform(0, W), -10, 1, PALETTE, speed=(40, 140), shape="square",
                            life=(2.5, 4.0), size=(3, 6), angle=(70, 110), gravity=40)
        self.particles.update(dt)

    def draw(self, screen):
        a = self.assets
        self.bg.draw_back(screen)
        pulse = 0.75 + 0.25 * math.sin(self.t * 3)
        glow = pygame.transform.smoothscale(self.glow, (int(560 * pulse), int(560 * pulse)))
        screen.blit(glow, glow.get_rect(center=(1050, 500)), special_flags=pygame.BLEND_ADD)
        self.smoke.draw(screen)
        self.player.draw(screen)
        self.particles.draw(screen)
        self.bg.draw_front(screen)
        drop = ease_out_back(self.t / 0.9)
        y = lerp(-100, 105, drop)
        gold = tuple(int(c * (0.88 + 0.12 * math.sin(self.t * 5))) for c in settings.GOLD)
        a.draw_text(screen, "SHOW FINALIZADO!", 80, gold, (520, y), outline=6, outline_color=(80, 35, 0))
        fade = clamp((self.t - 0.6) / 0.5, 0, 1) * 255
        for text, size, color, yy in (("PARABÉNS!", 68, settings.WHITE, 220),
                                      (f"SCORE: {self.score}", 56, (170, 220, 255), 305),
                                      (f"HIGH SCORE: {self.game.high_score}", 38, settings.GOLD, 365)):
            img = a.render_text(text, size, color, outline=3, outline_color=(30, 10, 60))
            blit_alpha(screen, img, img.get_rect(center=(520, yy)).topleft, fade)
        if self.is_new_record and self.t > 0.9:
            s = 1.0 + 0.08 * math.sin(self.t * 8)
            img = pygame.transform.rotozoom(
                a.render_text("NOVO RECORDE!", 44, (255, 120, 190), outline=3, outline_color=(60, 10, 40)), 0, s)
            screen.blit(img, img.get_rect(center=(520, 440)))
        self.menu.draw(screen)
