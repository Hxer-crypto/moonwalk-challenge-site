"""
settings.py
===========
TODAS as configurações do jogo ficam aqui. Para mudar a dificuldade, a
velocidade, as metas de pontos ou o volume, basta editar este arquivo.
"""

import sys

# ---------------------------------------------------------------- VERSÃO WEB / CELULAR
IS_WEB = sys.platform == "emscripten"      # True quando roda no navegador (pygbag)
TOUCH_UI = "auto"        # botões de toque: "auto" (web ou ao detectar toque) | True (sempre) | False (nunca)
LOW_QUALITY = IS_WEB     # menos partículas/fumaça (celular é mais fraco). Mude para True/False à vontade.
PARTICLE_SCALE = 0.5 if LOW_QUALITY else 1.0   # fração das partículas criadas
SMOKE_SCALE = 0.5 if LOW_QUALITY else 1.0      # fração da fumaça de palco

# ---------------------------------------------------------------- JANELA
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
TITLE = "Michael Jackson: Moonwalk Challenge"
MAX_DT = 0.05            # limite do delta time (evita "saltos" se o jogo travar)
FADE_TIME = 0.35         # duração de cada fade (entrada/saída) em segundos

# ---------------------------------------------------------------- JOGADOR
PLAYER_SPEED = 450       # pixels por segundo
INITIAL_LIVES = 3
FRAME_SIZE = 160         # cada frame do sprite tem 160x160 px
PLAYER_FLOOR_Y = 668     # y dos pés do personagem (linha do palco)
PLAYER_HITBOX_SIZE = (46, 112)   # caixa de colisão (menor que o sprite, mais justo)
PIC_SIZE_BOOST = 1.6     # os Michaels "*" aparecem 1,6x maiores no jogo (1.0 = tamanho antigo)
PIC_HITBOX_FACTOR = 0.6  # quanto da ampliação vale para a caixa de colisão (0 = não cresce, 1 = cresce igual)
INVULNERABLE_TIME = 1.6  # segundos piscando depois de tomar dano
HIT_ANIM_TIME = 0.5      # tempo da animação de dano

# ---------------------------------------------------------------- MOONWALK
MOONWALK_DURATION = 3.0      # quanto tempo dura o moonwalk (o som dura o mesmo tempo)
MOONWALK_COOLDOWN = 7.0      # tempo de recarga (conta a partir do momento em que ativa)
MOONWALK_BONUS = 25          # pontos ao ativar
MOONWALK_SCORE_MULT = 2      # multiplicador dos coletáveis durante o moonwalk
MOONWALK_SPEED_MULT = 1.15   # bônus de velocidade durante o moonwalk

# ---------------------------------------------------------------- PODER "INCLINAÇÃO" (Smooth Criminal)
# Ele se inclina 45°, fica um tempo e volta. Enquanto inclinado: NÃO toma dano e os itens que dão ponto
# são puxados para ele como um ímã. Depois de voltar ainda fica protegido por LEAN_GRACE segundos.
LEAN_DURATION = 3.0          # duração total do poder (ir + ficar + voltar), igual ao moonwalk
LEAN_COOLDOWN = 7.0          # tempo de recarga
LEAN_GRACE = 0.5             # proteção extra depois de voltar (para o objeto que já caiu perto não dar dano)
LEAN_CAN_MOVE = False         # True = pode andar enquanto está inclinado
LEAN_BONUS = 25              # pontos ao ativar
LEAN_MAGNET_RADIUS = 460     # alcance do ímã (px)
LEAN_MAGNET_SPEED = 950      # velocidade com que os itens voam até ele (px/s)

# ---------------------------------------------------------------- DIFICULDADE
OBSTACLE_SPEED = 200         # velocidade base de queda (px/s)
SPAWN_RATE = 1.0             # multiplicador global de spawn (2.0 = o dobro de objetos)
RAMP_SECONDS = 45.0          # em quanto tempo a dificuldade "sobe" dentro de uma fase
RAMP_SPEED_BONUS = 0.20      # aumento máximo de velocidade dentro da fase (+20%)
FLOOR_KILL_Y = 676           # objetos que "batem no chão" (bottom passa desta linha) somem

# ---------------------------------------------------------------- PONTUAÇÃO
STAR_POINTS = 10
NOTE_POINTS = 20
GOLDEN_STAR_POINTS = 50
SURVIVE_INTERVAL = 1.0       # a cada X segundos vivo...
SURVIVE_POINTS = 1           # ...ganha Y pontos
COLLECTIBLE_WEIGHTS = {"star": 55, "note": 33, "golden_star": 12}   # chance relativa

# Metas (pontuação TOTAL para terminar cada fase). A ÚLTIMA fase termina o jogo.
# Ordem: 1 Billie Jean, 2 Thriller, 3 Bad, 4 Smooth Criminal, 5 Remember the Time, 6 Jam,
#        7 Blood on the Dance Floor, 8 You Rock My World, 9 Chicago, 10 Blue Gangsta
PHASE_1_SCORE = 2000
PHASE_2_SCORE = 3200
PHASE_3_SCORE = 4500
PHASE_4_SCORE = 6700
PHASE_5_SCORE = 9000
PHASE_6_SCORE = 10000
PHASE_7_SCORE = 11000
PHASE_8_SCORE = 12000
PHASE_9_SCORE = 20000
PHASE_10_SCORE = 26000

# ---------------------------------------------------------------- ÁUDIO (valores INICIAIS)
# O jogador pode mudar tudo isso em CONFIGURAÇÕES (fica salvo em user_settings.json).
DEFAULT_MASTER_VOLUME = 1.0     # volume geral
DEFAULT_MUSIC_VOLUME = 0.80     # volume de CADA música (menu e fases)
DEFAULT_SFX_VOLUME = 0.30       # efeitos sonoros (bem mais baixos que a música)
AMBIENCE_FACTOR = 0.5           # ambiente do público = efeitos x este valor
# Duração MÁXIMA dos efeitos longos (o arquivo é cortado com um fade-out suave no final).
# Para o som tocar inteiro, coloque um valor maior que a duração do arquivo.
MOONWALK_SOUND_TIME = 2.0       # som do moonwalk (segundos) - separado da duração do poder
PHASE_CHANGE_SOUND_TIME = 2.0   # som da troca de fase (segundos)
LEAN_SOUND_TIME = 2.0           # som do poder de inclinação (segundos)
SOUND_FADEOUT = 0.4             # duração do fade-out no final do corte (segundos)
PHASE_MUSIC_DELAY = 2.2         # troca de fase: a música antiga some e a nova entra depois deste tempo (s)

# ---------------------------------------------------------------- FIGURINOS (skins)
# Figurinos (um por fase) desenhados por tools/gen_player.py com base nas suas fotos de referência.
SKINS = ["billie_jean", "thriller", "bad", "smooth", "remember", "jam",
         "blood", "yrmw", "chicago", "gangsta"]
PIC_SKINS_WITH_LEAN = list(SKINS)         # todos têm a animação de inclinação

# ---------------------------------------------------------------- FASES
# obstacle_interval / collectible_interval = (intervalo no início da fase,
# intervalo no fim da fase) em segundos. O jogo interpola entre os dois valores.
# music  = nome da música (arquivo assets/sounds/music/<music>_theme.wav/.ogg/.mp3)
# music_fallback = música que toca ENQUANTO o arquivo da fase não existe
# skin   = figurino do personagem (assets/images/player/player_<skin>_*.png)
# power  = "moonwalk" ou "lean" (inclinação do Smooth Criminal); power_name = nome mostrado no HUD
# power_sound = som do poder (e quantos segundos ele toca: power_sound_time, separado da duração do poder)
# bg_beams / bg_colors = raios de luz animados; crowd_sway = plateia balança?
_MOON = {"power": "moonwalk", "power_name": "MOONWALK", "power_sound": "moonwalk",
         "power_sound_time": MOONWALK_SOUND_TIME}
_LEAN = {"power": "lean", "power_name": "INCLINAÇÃO", "power_sound": "moonwalk",
         "power_sound_time": LEAN_SOUND_TIME}

PHASES = [
    {   # 1 - fase original
        "name": "FASE 1", "title": "BILLIE JEAN", "subtitle": "MOTOWN 25",
        "goal": PHASE_1_SCORE, "background": "billie", "music": "stage_1", "skin": "billie_jean",
        "speed_mult": 0.85, "obstacle_interval": (2.3, 1.8), "collectible_interval": (1.0, 0.9),
        "max_obstacles": 3, "obstacle_types": ["speaker", "microphone"], "smoke": 0.3,
        "bg_beams": 2, "bg_colors": [(255, 250, 230), (255, 214, 130)], "crowd_sway": True, **_MOON,
    },
    {   # 2 - NOVA
        "name": "FASE 2", "title": "THRILLER", "subtitle": "A NOITE DOS ZUMBIS",
        "goal": PHASE_2_SCORE, "background": "thriller", "music": "thriller", "music_fallback": "stage_4",
        "skin": "thriller",
        "speed_mult": 0.95, "obstacle_interval": (2.0, 1.55), "collectible_interval": (1.0, 0.9),
        "max_obstacles": 3, "obstacle_types": ["speaker", "microphone", "stage_light"], "smoke": 0.9,
        "bg_beams": 2, "bg_colors": [(120, 255, 190), (210, 235, 225)], "crowd_sway": False, **_MOON,
    },
    {   # 3 - fase original
        "name": "FASE 3", "title": "BAD", "subtitle": "BAD TOUR",
        "goal": PHASE_3_SCORE, "background": "bad", "music": "stage_2", "skin": "bad",
        "speed_mult": 1.05, "obstacle_interval": (1.8, 1.35), "collectible_interval": (0.95, 0.85),
        "max_obstacles": 4, "obstacle_types": ["speaker", "microphone", "stage_light"], "smoke": 0.6,
        "bg_beams": 4, "bg_colors": [(255, 60, 80), (255, 255, 255)], "crowd_sway": True, **_MOON,
    },
    {   # 4 - NOVA (poder diferente: inclinação)
        "name": "FASE 4", "title": "SMOOTH CRIMINAL", "subtitle": "O CLUBE",
        "goal": PHASE_4_SCORE, "background": "smooth", "music": "smooth", "music_fallback": "stage_1",
        "skin": "smooth",
        "speed_mult": 1.15, "obstacle_interval": (1.65, 1.2), "collectible_interval": (0.95, 0.85),
        "max_obstacles": 5, "obstacle_types": ["speaker", "microphone", "stage_light"], "smoke": 0.4,
        "bg_beams": 3, "bg_colors": [(255, 225, 150), (170, 200, 255)], "crowd_sway": True, **_LEAN,
    },
    {   # 5 - fase original
        "name": "FASE 5", "title": "REMEMBER THE TIME", "subtitle": "O CLIPE NO EGITO",
        "goal": PHASE_5_SCORE, "background": "remember", "music": "stage_3", "skin": "remember",
        "speed_mult": 1.25, "obstacle_interval": (1.5, 1.05), "collectible_interval": (0.9, 0.8),
        "max_obstacles": 5, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light"],
        "smoke": 0.8, "bg_beams": 2, "bg_colors": [(255, 200, 110), (255, 236, 170)], "crowd_sway": False, **_MOON,
    },
    {   # 6 - NOVA
        "name": "FASE 6", "title": "JAM", "subtitle": "DANGEROUS TOUR 93",
        "goal": PHASE_6_SCORE, "background": "jam", "music": "jam", "music_fallback": "stage_2",
        "skin": "jam",
        "speed_mult": 1.35, "obstacle_interval": (1.35, 1.0), "collectible_interval": (0.9, 0.8),
        "max_obstacles": 6, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light"],
        "smoke": 0.7, "bg_beams": 5, "bg_colors": [(255, 60, 180), (60, 220, 255), (255, 220, 60)],
        "crowd_sway": True, **_MOON,
    },
    {   # 7 - NOVA (figurino: terno e calça de couro vinho)
        "name": "FASE 7", "title": "BLOOD ON THE DANCE FLOOR", "subtitle": "VIDRO E NEON",
        "goal": PHASE_7_SCORE, "background": "blood", "music": "blood", "music_fallback": "stage_3",
        "skin": "blood",
        "speed_mult": 1.40, "obstacle_interval": (1.3, 0.95), "collectible_interval": (0.88, 0.78),
        "max_obstacles": 7, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light"],
        "smoke": 0.5, "bg_beams": 4, "bg_colors": [(255, 40, 90), (255, 160, 190)], "crowd_sway": False, **_MOON,
    },
    {   # 8 - fase original
        "name": "FASE 8", "title": "YOU ROCK MY WORLD", "subtitle": "CLIPE E AO VIVO",
        "goal": PHASE_8_SCORE, "background": "yrmw", "music": "stage_4", "skin": "yrmw",
        "speed_mult": 1.45, "obstacle_interval": (1.2, 0.9), "collectible_interval": (0.85, 0.75),
        "max_obstacles": 7, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light"],
        "smoke": 0.7, "bg_beams": 4, "bg_colors": [(255, 190, 90), (255, 240, 200)], "crowd_sway": True, **_MOON,
    },
    {   # 9 - fase original
        "name": "FASE 9", "title": "CHICAGO", "subtitle": "XSCAPE",
        "goal": PHASE_9_SCORE, "background": "chicago", "music": "stage_5", "skin": "chicago",
        "speed_mult": 1.65, "obstacle_interval": (1.0, 0.7), "collectible_interval": (0.8, 0.65),
        "max_obstacles": 9, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light",
                                               "stage_light"],
        "smoke": 1.0, "bg_beams": 3, "bg_colors": [(150, 190, 255), (255, 200, 120)], "crowd_sway": False, **_MOON,
    },
    {   # 10 - NOVA (figurino: terno dourado)
        "name": "FASE 10", "title": "BLUE GANGSTA", "subtitle": "NOITE DE CHUVA",
        "goal": PHASE_10_SCORE, "background": "gangsta", "music": "gangsta", "music_fallback": "stage_5",
        "skin": "gangsta",
        "speed_mult": 1.75, "obstacle_interval": (0.95, 0.65), "collectible_interval": (0.78, 0.62),
        "max_obstacles": 10, "obstacle_types": ["speaker", "microphone", "stage_light", "stage_light",
                                                "stage_light"],
        "smoke": 0.9, "bg_beams": 3, "bg_colors": [(90, 160, 255), (190, 220, 255)], "crowd_sway": True, **_MOON,
    },
]

# ---------------------------------------------------------------- CORES
WHITE = (255, 255, 255)
GOLD = (255, 214, 80)
PURPLE = (150, 90, 230)
BLUE = (90, 170, 255)
RED = (235, 65, 85)
DARK = (10, 8, 24)
