"""
hud.py
======
Interface durante a partida:

    topo esquerdo : SCORE (+ recorde)
    topo central  : FASE (+ barra de progresso até a meta)
    topo direito  : VIDAS (corações)
    embaixo       : barra de recarga do MOONWALK
"""
import pygame

from scripts import settings

W = settings.SCREEN_WIDTH


class HUD:
    def __init__(self, assets):
        self.assets = assets
        self.panel_left = self._panel((300, 86))
        self.panel_center = self._panel((360, 90))
        self.panel_right = self._panel((236, 86))

    @staticmethod
    def _panel(size):
        surf = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.rect(surf, (8, 4, 24, 175), surf.get_rect(), border_radius=16)
        pygame.draw.rect(surf, (150, 100, 240, 210), surf.get_rect(), width=2, border_radius=16)
        return surf

    def draw(self, surface, scene):
        a = self.assets
        phases = settings.PHASES

        # ---- SCORE (topo esquerdo)
        surface.blit(self.panel_left, (16, 14))
        a.draw_text(surface, f"SCORE: {scene.score}", 36, settings.WHITE, (34, 24), "topleft",
                    outline=2, outline_color=(20, 10, 50))
        a.draw_text(surface, f"RECORDE: {max(scene.game.high_score, scene.score)}", 22, (190, 170, 255),
                    (34, 66), "topleft", kind="secondary")

        # ---- FASE (topo central): número, música e progresso
        surface.blit(self.panel_center, (W // 2 - 180, 14))
        ph = phases[scene.phase_index]
        a.draw_text(surface, ph["name"], 30, settings.GOLD, (W // 2, 18), "midtop",
                    outline=2, outline_color=(60, 30, 0))
        a.draw_text(surface, ph["title"], 20, (220, 205, 255), (W // 2, 50), "midtop", kind="secondary")
        prev_goal = phases[scene.phase_index - 1]["goal"] if scene.phase_index > 0 else 0
        goal = ph["goal"]
        progress = max(0.0, min(1.0, (scene.score - prev_goal) / max(1, goal - prev_goal)))
        bar = pygame.Rect(W // 2 - 150, 76, 300, 10)
        pygame.draw.rect(surface, (40, 28, 80), bar, border_radius=5)
        if progress > 0:
            fill = bar.copy()
            fill.width = max(8, int(bar.width * progress))
            pygame.draw.rect(surface, settings.GOLD, fill, border_radius=5)
        pygame.draw.rect(surface, (200, 170, 255), bar, width=2, border_radius=5)

        # ---- VIDAS (topo direito)
        surface.blit(self.panel_right, (W - 16 - 236, 14))
        a.draw_text(surface, "VIDAS", 20, (190, 170, 255), (W - 16 - 236 + 118, 22), "midtop", kind="secondary")
        heart, empty = a.images["heart"], a.images["heart_empty"]
        total = settings.INITIAL_LIVES
        start_x = W - 16 - 236 + 118 - (total * 48) // 2 + 2
        for i in range(total):
            surface.blit(heart if i < scene.lives else empty, (start_x + i * 48, 40))

        # ---- MOONWALK (embaixo)
        ratio = scene.player.moonwalk_ratio
        bar = pygame.Rect(W // 2 - 60, 698, 240, 12)
        pygame.draw.rect(surface, (20, 10, 44), bar.inflate(6, 6), border_radius=8)
        pygame.draw.rect(surface, (60, 40, 110), bar, border_radius=6)
        color = settings.GOLD if ratio >= 1.0 else (140, 100, 230)
        if ratio > 0:
            fill = bar.copy()
            fill.width = int(bar.width * ratio)
            pygame.draw.rect(surface, color, fill, border_radius=6)
        pname = ph.get("power_name", "MOONWALK")
        key = "TOQUE" if scene.touch.enabled else "ESPAÇO"
        label = f"{key}: {pname} PRONTO!" if ratio >= 1.0 else f"{pname} recarregando..."
        a.draw_text(surface, label, 20, settings.GOLD if ratio >= 1.0 else (200, 190, 240),
                    (bar.left - 14, bar.centery), "midright", kind="secondary", outline=2,
                    outline_color=(10, 5, 25))
