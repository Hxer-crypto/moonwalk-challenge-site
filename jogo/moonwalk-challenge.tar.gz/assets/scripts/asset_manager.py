"""
asset_manager.py
================
Carrega TODOS os recursos (imagens, sons, fontes) UMA ÚNICA VEZ e guarda em
dicionários. O resto do jogo só consulta:

    assets.images["star"]
    assets.sounds["hit"]

Se um arquivo estiver faltando, o jogo NÃO quebra: mostra um aviso claro no
console (com o nome do arquivo) e usa um placeholder no lugar.
"""
import os

import pygame

from scripts import settings
from scripts.utils import resource_path

FS = settings.FRAME_SIZE

# chave -> (caminho dentro de assets/images, tamanho do placeholder)
IMAGE_FILES = {
    # (as tiras do personagem de cada figurino são adicionadas logo abaixo)
    # coletáveis
    "star": ("collectibles/star.png", (64, 64)),
    "note": ("collectibles/note.png", (64, 64)),
    "golden_star": ("collectibles/golden_star.png", (64, 64)),
    # obstáculos
    "speaker": ("obstacles/speaker.png", (96, 112)),
    "microphone": ("obstacles/microphone.png", (64, 112)),
    "stage_light": ("obstacles/stage_light.png", (96, 96)),
    # interface
    "heart": ("ui/heart.png", (44, 44)),
    "heart_empty": ("ui/heart_empty.png", (44, 44)),
    "icon_hit": ("ui/icon_hit.png", (48, 48)),
    # efeitos
    "glow": ("effects/glow.png", (128, 128)),
    "smoke": ("effects/smoke.png", (128, 128)),
    # camada de frente (vinheta) compartilhada
    "bg_front": ("backgrounds/bg_front.png", (settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT)),
}

# personagem: 5 figurinos x 6 animações (tiras horizontais de frames 160x160)
PLAYER_ANIMS = {"idle": 6, "walk_left": 6, "walk_right": 6, "moonwalk": 6, "hit": 3, "victory": 4}
PLAYER_ANIMS_LEAN = dict(PLAYER_ANIMS, lean=8)       # figurinos "pic_*" também têm a animação de inclinação
for _skin in settings.SKINS:
    _anims = PLAYER_ANIMS_LEAN if _skin in settings.PIC_SKINS_WITH_LEAN else PLAYER_ANIMS
    for _anim, _n in _anims.items():
        IMAGE_FILES[f"player_{_skin}_{_anim}"] = (f"player/player_{_skin}_{_anim}.png", (FS * _n, FS))

BACKGROUND_NAMES = ["menu"]
for _ph in settings.PHASES:
    if _ph["background"] not in BACKGROUND_NAMES:
        BACKGROUND_NAMES.append(_ph["background"])
for _name in BACKGROUND_NAMES:
    IMAGE_FILES[f"bg_{_name}_back"] = (f"backgrounds/bg_{_name}_back.png", (1280, 720))
    IMAGE_FILES[f"bg_{_name}_lights"] = (f"backgrounds/bg_{_name}_lights.png", (1400, 720))
    IMAGE_FILES[f"bg_{_name}_crowd"] = (f"backgrounds/bg_{_name}_crowd.png", (1400, 720))
    IMAGE_FILES[f"bg_{_name}_floor"] = (f"backgrounds/bg_{_name}_floor.png", (1280, 720))

# Áudio: SEM extensão. O jogo procura .wav, .ogg ou .mp3 (usa o arquivo mais recente).
AUDIO_EXTENSIONS = (".wav", ".ogg", ".mp3")

SOUND_FILES = {
    "collect_star": "sfx/collect_star",
    "collect_note": "sfx/collect_note",
    "collect_golden": "sfx/collect_golden",
    "hit": "sfx/hit",
    "button": "sfx/button",
    "phase_change": "sfx/phase_change",
    "victory": "sfx/victory",
    "game_over": "sfx/game_over",
    "moonwalk": "sfx/moonwalk",
    "crowd": "ambience/crowd",
}

MUSIC_FILES = {"menu_theme": "music/menu_theme"}
MUSIC_FALLBACK = {}      # música da fase -> música que toca enquanto o arquivo dela não existe
for _ph in settings.PHASES:
    MUSIC_FILES[_ph["music"]] = f"music/{_ph['music']}_theme"
    if _ph.get("music_fallback"):
        MUSIC_FALLBACK[_ph["music"]] = _ph["music_fallback"]


def find_audio(rel_base):
    """Acha assets/sounds/<rel_base>.(wav|ogg|mp3). Se houver mais de um, usa o mais novo."""
    found = []
    for ext in AUDIO_EXTENSIONS:
        path = resource_path("assets", "sounds", *(rel_base + ext).split("/"))
        if os.path.isfile(path):
            found.append(path)
    if not found:
        return None
    return max(found, key=os.path.getmtime)


class NullSound:
    """Som "de mentira": usado quando o arquivo falta ou o áudio não está disponível."""

    def play(self, *args, **kwargs):
        return None

    def stop(self):
        pass

    def set_volume(self, value):
        pass

    def get_length(self):
        return 0.0


class AssetManager:
    def __init__(self):
        self.images = {}
        self.sounds = {}
        self.music = {}          # nome -> caminho do arquivo (a música é "streamada")
        self.missing = []        # lista de arquivos que não foram encontrados
        self._fonts = {}
        self._text_cache = {}
        self.load_all()

    # ------------------------------------------------------------ carregamento
    def load_all(self):
        for key, (rel, size) in IMAGE_FILES.items():
            self.images[key] = self._load_image(rel, size)
        for key, rel in SOUND_FILES.items():
            self.sounds[key] = self._load_sound(rel)
        for key, rel in MUSIC_FILES.items():
            path = find_audio(rel)
            if path:
                self.music[key] = path
            else:
                self.music[key] = None
                if key not in MUSIC_FALLBACK:
                    self._report_missing(resource_path("assets", "sounds", rel + ".wav"))
        # fases novas sem música própria: toca uma música provisória (coloque o arquivo e ela é trocada)
        for key, fb in MUSIC_FALLBACK.items():
            if self.music.get(key) is None:
                self.music[key] = self.music.get(fb)
                print("[AVISO] Sem música para '%s' (assets/sounds/%s.wav/.ogg/.mp3). Tocando '%s' no lugar."
                      % (key, MUSIC_FILES[key], fb))
        if self.missing:
            print("\n[AVISO] Faltam %d arquivo(s) de assets. Para recriá-los, rode:\n"
                  "        python tools/generate_assets.py\n" % len(self.missing))

    def _report_missing(self, path):
        rel = os.path.relpath(path, resource_path())
        self.missing.append(rel)
        print(f"[AVISO] Arquivo não encontrado: {rel}")

    def _load_image(self, rel, size):
        path = resource_path("assets", "images", *rel.split("/"))
        if os.path.isfile(path):
            try:
                return pygame.image.load(path).convert_alpha()
            except pygame.error as err:
                print(f"[AVISO] Imagem inválida ({rel}): {err}")
                self.missing.append(os.path.relpath(path, resource_path()))
        else:
            self._report_missing(path)
        return self._placeholder(size, dark=rel.endswith("_back.png"))

    def _load_sound(self, rel):
        if not pygame.mixer.get_init():
            return NullSound()
        path = find_audio(rel)
        if path:
            try:
                return pygame.mixer.Sound(path)
            except pygame.error as err:
                print(f"[AVISO] Som inválido ({os.path.basename(path)}): {err}")
        else:
            self._report_missing(resource_path("assets", "sounds", rel + ".wav"))
        return NullSound()

    @staticmethod
    def _placeholder(size, dark=False):
        """Quadriculado magenta/preto: fácil de perceber que falta uma imagem."""
        surf = pygame.Surface(size, pygame.SRCALPHA)
        if dark:
            surf.fill((20, 10, 40, 255))
            return surf
        block = 16
        for y in range(0, size[1], block):
            for x in range(0, size[0], block):
                color = (255, 0, 255, 200) if (x // block + y // block) % 2 == 0 else (0, 0, 0, 200)
                surf.fill(color, (x, y, block, block))
        return surf

    # ------------------------------------------------------------ fontes
    def font(self, size, kind="main"):
        """Fonte principal (arcade/impacto) ou secundária (leitura).

        Para usar uma fonte própria, coloque um .ttf em assets/fonts/ com nome
        'main.ttf' (principal) ou 'secondary.ttf' (secundária).
        """
        key = (size, kind)
        if key in self._fonts:
            return self._fonts[key]
        font = None
        for ext in ("ttf", "otf"):
            path = resource_path("assets", "fonts", f"{kind}.{ext}")
            if os.path.isfile(path):
                try:
                    font = pygame.font.Font(path, size)
                    break
                except (pygame.error, OSError):
                    font = None
        if font is None:
            if kind == "main":
                for name in ("impact", "arialblack", "bahnschrift", "franklingothicheavy"):
                    path = pygame.font.match_font(name)
                    if path:
                        font = pygame.font.Font(path, size)
                        break
                if font is None:
                    font = pygame.font.SysFont("arial,dejavusans,verdana", size, bold=True)
            else:
                font = pygame.font.SysFont("segoeui,arial,dejavusans,verdana", size)
        self._fonts[key] = font
        return font

    def render_text(self, text, size, color, kind="main", outline=0, outline_color=(0, 0, 0)):
        """Renderiza texto com cache (renderizar fonte a cada frame é lento)."""
        key = (text, size, color, kind, outline, outline_color)
        surf = self._text_cache.get(key)
        if surf is None:
            if len(self._text_cache) > 400:
                self._text_cache.clear()
            font = self.font(size, kind)
            base = font.render(text, True, color)
            if outline > 0:
                w, h = base.get_size()
                surf = pygame.Surface((w + outline * 2, h + outline * 2), pygame.SRCALPHA)
                border = font.render(text, True, outline_color)
                for dx in range(-outline, outline + 1):
                    for dy in range(-outline, outline + 1):
                        if dx * dx + dy * dy <= outline * outline + 1:
                            surf.blit(border, (outline + dx, outline + dy))
                surf.blit(base, (outline, outline))
            else:
                surf = base
            self._text_cache[key] = surf
        return surf

    def draw_text(self, target, text, size, color, pos, anchor="center", kind="main",
                  outline=0, outline_color=(0, 0, 0)):
        """Desenha texto usando um 'anchor' pygame: center, topleft, midleft, topright..."""
        surf = self.render_text(text, size, color, kind, outline, outline_color)
        rect = surf.get_rect(**{anchor: pos})
        target.blit(surf, rect)
        return rect
