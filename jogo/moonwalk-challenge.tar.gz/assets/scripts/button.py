"""
button.py
=========
Widgets de menu: Button (3 estados: normal, hover, pressionado), Slider (volume)
e ButtonMenu (gerencia mouse + teclado: setas/W/S para navegar, ENTER/ESPAÇO
para escolher).
"""
import pygame

from scripts import settings


class Button:
    def __init__(self, text, center, callback, assets, audio, size=(380, 62), font_size=34):
        self.text = text
        self.callback = callback
        self.assets = assets
        self.audio = audio
        self.font_size = font_size
        self.rect = pygame.Rect(0, 0, *size)
        self.rect.center = center
        self.selected = False     # "hover" (mouse por cima OU selecionado pelo teclado)
        self.pressed = False

    def set_text(self, text):
        self.text = text

    def activate(self):
        """Clique: som + ação."""
        self.audio.play("button")
        self.callback()

    def handle_mouse(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.pressed = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was_pressed = self.pressed
            self.pressed = False
            if was_pressed and self.rect.collidepoint(event.pos):
                self.activate()

    def draw(self, surface):
        r = self.rect.copy()
        if self.pressed:                       # ESTADO PRESSIONADO
            fill, border, color = (22, 12, 46), settings.WHITE, settings.WHITE
            r.y += 3
        elif self.selected:                    # ESTADO HOVER
            fill, border, color = (66, 34, 120), settings.GOLD, settings.GOLD
        else:                                  # ESTADO NORMAL
            fill, border, color = (30, 20, 64), (110, 84, 200), settings.WHITE
        pygame.draw.rect(surface, fill, r, border_radius=16)
        pygame.draw.rect(surface, border, r, width=3, border_radius=16)
        if self.selected and not self.pressed:   # brilho no topo
            pygame.draw.line(surface, (140, 100, 230), (r.left + 18, r.top + 5), (r.right - 18, r.top + 5), 2)
        label = self.assets.render_text(self.text, self.font_size, color, outline=2, outline_color=(10, 5, 25))
        surface.blit(label, label.get_rect(center=r.center))
        if self.selected:                      # seta "▶" desenhada (não depende da fonte)
            cx, cy = r.left + 26, r.centery
            pygame.draw.polygon(surface, settings.GOLD, [(cx - 7, cy - 10), (cx - 7, cy + 10), (cx + 9, cy)])


class Slider:
    """Barra de volume com segmentos clicáveis (também funciona com ← →).

    steps = quantos segmentos (20 = passos de 5%). Mostra a porcentagem no fim.
    """

    def __init__(self, label, center, value, on_change, assets, audio, size=(760, 56), label_w=300,
                 steps=20, font_size=26):
        self.label = label
        self.value = value
        self.on_change = on_change
        self.assets = assets
        self.audio = audio
        self.steps = steps
        self.font_size = font_size
        self.rect = pygame.Rect(0, 0, *size)
        self.rect.center = center
        self.selected = False
        self.bar = pygame.Rect(self.rect.left + label_w, self.rect.centery - 11,
                               self.rect.width - label_w - 90, 22)

    def set_value(self, value):
        value = max(0.0, min(1.0, round(value * self.steps) / self.steps))
        if abs(value - self.value) > 1e-6:
            self.value = value
            self.on_change(value)
            self.audio.play("button")

    def activate(self):
        pass

    def on_arrow(self, direction):
        self.set_value(self.value + direction / self.steps)

    def handle_mouse(self, event):
        inside = self.bar.inflate(10, 24)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and inside.collidepoint(event.pos):
            self._from_x(event.pos[0])
        elif event.type == pygame.MOUSEMOTION and event.buttons[0] and inside.collidepoint(event.pos):
            self._from_x(event.pos[0])

    def _from_x(self, x):
        self.set_value((x - self.bar.left) / self.bar.width)

    def draw(self, surface):
        border = settings.GOLD if self.selected else (110, 84, 200)
        pygame.draw.rect(surface, (66, 34, 120) if self.selected else (30, 20, 64), self.rect, border_radius=16)
        pygame.draw.rect(surface, border, self.rect, width=3, border_radius=16)
        self.assets.draw_text(surface, self.label, self.font_size, settings.WHITE,
                              (self.rect.left + 22, self.rect.centery), anchor="midleft", outline=2,
                              outline_color=(10, 5, 25))
        seg_w = self.bar.width / self.steps
        for i in range(self.steps):
            seg = pygame.Rect(int(self.bar.left + i * seg_w) + 1, self.bar.top, max(2, int(seg_w) - 2),
                              self.bar.height)
            on = (i + 1) / self.steps <= self.value + 0.001
            pygame.draw.rect(surface, (255, 214, 80) if on else (50, 36, 90), seg, border_radius=3)
        self.assets.draw_text(surface, f"{int(round(self.value * 100))}%", 26, settings.WHITE,
                              (self.rect.right - 22, self.rect.centery), anchor="midright", outline=2,
                              outline_color=(10, 5, 25))


class ButtonMenu:
    """Junta vários widgets e cuida da navegação por mouse e teclado."""

    def __init__(self, widgets, selected=0):
        self.widgets = widgets
        self.selected = selected
        self._sync()

    def _sync(self):
        for i, w in enumerate(self.widgets):
            w.selected = (i == self.selected)

    def handle_event(self, event):
        if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            for i, w in enumerate(self.widgets):
                if w.rect.collidepoint(event.pos):
                    self.selected = i
                    self._sync()
        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_UP, pygame.K_w):
                self.selected = (self.selected - 1) % len(self.widgets)
                self._sync()
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self.selected = (self.selected + 1) % len(self.widgets)
                self._sync()
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.widgets[self.selected].activate()
            elif event.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
                w = self.widgets[self.selected]
                if hasattr(w, "on_arrow"):
                    w.on_arrow(-1 if event.key in (pygame.K_LEFT, pygame.K_a) else 1)
        for w in self.widgets:
            w.handle_mouse(event)

    def draw(self, surface):
        for w in self.widgets:
            w.draw(surface)
