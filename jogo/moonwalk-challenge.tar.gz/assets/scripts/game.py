"""
game.py
=======
A classe Game é o "coração" do projeto:
  * inicializa pygame, janela, assets e áudio;
  * guarda a cena ativa (menu, jogo, pausa...);
  * faz o game loop:  eventos -> update -> draw -> flip -> controle de FPS;
  * faz as transições (fade out / fade in) entre as cenas;
  * guarda o recorde (high score).
"""
import asyncio
import sys

import pygame

from scripts import settings
from scripts.asset_manager import AssetManager
from scripts.audio_manager import AudioManager
from scripts.scenes import MenuScene
from scripts.utils import load_high_score, save_high_score


class Game:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        try:
            pygame.mixer.init()
        except pygame.error as err:
            print(f"[AVISO] Áudio indisponível, o jogo rodará sem som: {err}")

        self.touch_seen = False       # vira True quando a tela detecta um toque (aí aparecem os botões)
        if settings.IS_WEB:           # navegador/celular: janela simples (o navegador cuida da escala)
            self.screen = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
        else:
            # SCALED + RESIZABLE: a janela pode ser redimensionada mantendo 16:9 (F11 = tela cheia)
            try:
                self.screen = pygame.display.set_mode(
                    (settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT), pygame.SCALED | pygame.RESIZABLE)
            except pygame.error:
                self.screen = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
        pygame.display.set_caption(settings.TITLE)

        self.clock = pygame.time.Clock()
        self.assets = AssetManager()          # carrega tudo UMA vez
        self.audio = AudioManager(self.assets)
        try:
            pygame.display.set_icon(pygame.transform.smoothscale(self.assets.images["golden_star"], (32, 32)))
        except pygame.error:
            pass

        self.high_score = load_high_score()
        self.running = True

        # controle de transição entre cenas
        self.scene = None
        self.next_scene = None
        self.fade_state = None        # None | "out" | "in"
        self.fade_alpha = 0.0
        self.fade_surface = pygame.Surface((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
        self.fade_surface.fill((0, 0, 0))

        self._switch_scene(MenuScene(self))

    # ------------------------------------------------------------ cenas
    def _switch_scene(self, scene):
        if self.scene is not None:
            self.scene.on_exit()
        self.scene = scene
        self.scene.on_enter()

    def change_scene(self, scene, fade=True):
        """Troca de cena. scene=None encerra o jogo. fade=False troca na hora."""
        if self.fade_state == "out":
            return                                   # já tem uma troca em andamento
        if not fade and scene is not None:
            self._switch_scene(scene)
            return
        self.next_scene = scene
        self.fade_state = "out"

    def _update_fade(self, dt):
        speed = 255.0 / settings.FADE_TIME
        if self.fade_state == "out":
            self.fade_alpha = min(255.0, self.fade_alpha + speed * dt)
            if self.fade_alpha >= 255.0:
                if self.next_scene is None:
                    self.running = False
                else:
                    self._switch_scene(self.next_scene)
                    self.next_scene = None
                    self.fade_state = "in"
        elif self.fade_state == "in":
            self.fade_alpha = max(0.0, self.fade_alpha - speed * dt)
            if self.fade_alpha <= 0.0:
                self.fade_state = None

    # ------------------------------------------------------------ recorde
    def update_high_score(self, score):
        """Compara a pontuação com o recorde. Devolve True se for um novo recorde."""
        if score > self.high_score:
            self.high_score = score
            save_high_score(score)
            return True
        return False

    # ------------------------------------------------------------ loop
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == getattr(pygame, "FINGERDOWN", -1):
                self.touch_seen = True                  # tela de toque detectada
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                if not settings.IS_WEB:
                    pygame.display.toggle_fullscreen()
            elif self.fade_state != "out":           # durante o fade-out ignoramos cliques
                self.scene.handle_event(event)

    def tick(self, dt):
        """Um quadro do jogo: eventos -> update -> draw."""
        self.handle_events()
        self.scene.update(dt)
        self.audio.update(dt)
        self.scene.draw(self.screen)
        self._update_fade(dt)
        if self.fade_alpha > 0:
            self.fade_surface.set_alpha(int(self.fade_alpha))
            self.screen.blit(self.fade_surface, (0, 0))

    def run(self):
        """Loop normal (computador)."""
        while self.running:
            dt = min(self.clock.tick(settings.FPS) / 1000.0, settings.MAX_DT)
            self.tick(dt)
            pygame.display.flip()
        pygame.quit()
        sys.exit()

    async def run_async(self):
        """Mesmo loop, mas "cooperativo": no navegador (pygbag) é obrigatório devolver o controle
        ao navegador a cada quadro (await asyncio.sleep(0))."""
        while self.running:
            dt = min(self.clock.tick(settings.FPS) / 1000.0, settings.MAX_DT)
            self.tick(dt)
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()
        if not settings.IS_WEB:
            sys.exit()
