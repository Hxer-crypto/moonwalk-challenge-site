"""
player.py
=========
O personagem: movimento, animações, dano, invencibilidade e MOONWALK.

Animação = lista de frames + velocidade (fps). A classe Animation avança os
frames automaticamente. Os frames vêm de "tiras" (sprite strips) em que cada
frame tem FRAME_SIZE x FRAME_SIZE pixels.
"""
import pygame

from scripts import settings
from scripts.utils import clamp, tint


# número de frames das animações ANTIGAS (6 de andar etc.); as novas têm mais frames e o jogo ajusta o fps
# para o ciclo durar o mesmo tempo
REF_FRAMES = {"idle": 6, "walk_left": 6, "walk_right": 6, "moonwalk": 6, "hit": 3, "victory": 4, "lean": 8}


def split_strip(strip, frame_size=settings.FRAME_SIZE, scale=1.0):
    """Corta uma tira horizontal de frames em uma lista de imagens."""
    count = max(1, strip.get_width() // frame_size)
    height = min(frame_size, strip.get_height())
    frames = []
    for i in range(count):
        frame = strip.subsurface((i * frame_size, 0, frame_size, height)).copy()
        if scale != 1.0:
            frame = pygame.transform.smoothscale(
                frame, (int(frame.get_width() * scale), int(frame.get_height() * scale)))
        frames.append(frame)
    return frames


class Animation:
    """Toca uma lista de frames em 'fps' quadros por segundo."""

    def __init__(self, frames, fps=10, loop=True):
        self.frames = frames
        self.fps = fps
        self.loop = loop
        self.time = 0.0

    def reset(self):
        self.time = 0.0

    def update(self, dt):
        self.time += dt

    @property
    def index(self):
        i = int(self.time * self.fps)
        return i % len(self.frames) if self.loop else min(i, len(self.frames) - 1)

    @property
    def image(self):
        return self.frames[self.index]


class Player(pygame.sprite.Sprite):
    ANIM_FPS = {"idle": 7, "walk_left": 12, "walk_right": 12, "moonwalk": 10, "hit": 8, "victory": 7, "lean": 10}

    def __init__(self, assets, x=settings.SCREEN_WIDTH / 2, floor_y=settings.PLAYER_FLOOR_Y, scale=1.0,
                 skin=None, boost=1.0):
        super().__init__()
        self.assets = assets
        self.scale = scale
        self.boost = boost               # ampliação extra dos figurinos "pic_*" (só na fase de jogo)
        self.floor_y = floor_y
        self.start_x = float(x)
        self.x = self.start_x
        self.skin = skin or settings.SKINS[0]
        self._skin_cache = {}            # figurino -> dicionário de animações (criadas só quando precisa)
        self.anims = self._anims_for(self.skin)
        # brilho dourado que aparece atrás dele durante o moonwalk
        aura_size = int(260 * self._skin_scale(self.skin))
        self.aura = tint(pygame.transform.smoothscale(assets.images["glow"], (aura_size, aura_size)), (255, 190, 70))
        self.rect = pygame.Rect(0, 0, 10, 10)
        self._apply_rect()
        self.reset()

    def _skin_scale(self, skin):
        """escala total do figurino: base (cena) x ampliação dos Michaels das imagens."""
        return self.scale * (self.boost if skin in settings.SKINS else 1.0)

    def _apply_rect(self):
        """caixa de colisão: cresce só uma parte da ampliação do sprite (para não ficar impossível)."""
        b = self.boost if self.skin in settings.SKINS else 1.0
        k = self.scale * (1.0 + (b - 1.0) * settings.PIC_HITBOX_FACTOR)
        w, h = settings.PLAYER_HITBOX_SIZE
        old = self.rect.midbottom
        self.rect.size = (int(w * k), int(h * k))
        self.rect.midbottom = old

    def _anims_for(self, skin):
        if skin not in self._skin_cache:
            im = self.assets.images
            sc = self._skin_scale(skin)
            anims = {}
            for name, fps in self.ANIM_FPS.items():
                strip = im.get(f"player_{skin}_{name}")
                if strip is None:                         # "lean" só existe nos figurinos pic_*
                    continue
                fs = strip.get_height()                   # frames quadrados: 160 (antigos) ou 320 (novos, nítidos)
                frames = split_strip(strip, frame_size=fs, scale=sc * settings.FRAME_SIZE / fs)
                fps = fps * len(frames) / REF_FRAMES.get(name, len(frames))
                anims[name] = Animation(frames, fps=fps, loop=(name != "hit"))
            self._skin_cache[skin] = anims
        return self._skin_cache[skin]

    def set_skin(self, skin):
        """Troca o figurino mantendo a animação atual."""
        if skin == self.skin:
            return
        old_time = self.anim.time if hasattr(self, "anim") else 0.0
        self.skin = skin
        self.anims = self._anims_for(skin)
        self._apply_rect()
        if hasattr(self, "state"):
            self.anim = self.anims[self.state]
            self.anim.time = old_time

    # ------------------------------------------------------------ estado
    def reset(self):
        self.x = self.start_x
        self.state = "idle"
        self.anim = self.anims["idle"]
        self.anim.reset()
        self.hit_timer = 0.0
        self.invulnerable_timer = 0.0
        self.moonwalk_timer = 0.0          # tempo restante do PODER (moonwalk ou inclinação)
        self.moonwalk_cooldown = 0.0
        self.grace_timer = 0.0             # proteção extra depois da inclinação
        self.rect.midbottom = (round(self.x), self.floor_y)

    def play(self, name):
        """Troca a animação atual (só reinicia se for diferente)."""
        if name != self.state:
            self.state = name
            self.anim = self.anims[name]
            self.anim.reset()

    # ---- poder da fase atual ("moonwalk" ou "lean"); configurado por set_power()
    power_kind = "moonwalk"
    power_duration = settings.MOONWALK_DURATION
    power_cooldown_total = settings.MOONWALK_COOLDOWN

    def set_power(self, phase):
        """Define o poder especial da fase (settings.PHASES[...]['power'])."""
        self.power_kind = phase.get("power", "moonwalk")
        if self.power_kind == "lean":
            self.power_duration = settings.LEAN_DURATION
            self.power_cooldown_total = settings.LEAN_COOLDOWN
        else:
            self.power_duration = settings.MOONWALK_DURATION
            self.power_cooldown_total = settings.MOONWALK_COOLDOWN
        self.moonwalk_timer = 0.0
        self.moonwalk_cooldown = min(self.moonwalk_cooldown, self.power_cooldown_total)

    @property
    def moonwalking(self):
        return self.moonwalk_timer > 0 and self.power_kind == "moonwalk"

    @property
    def leaning(self):
        return self.moonwalk_timer > 0 and self.power_kind == "lean"

    @property
    def shielded(self):
        """Protegido de dano pelo poder (inclinado OU nos 0,5 s depois de voltar)."""
        return self.leaning or self.grace_timer > 0

    @property
    def lean_progress(self):
        """0.0 (começou a se inclinar) ... 1.0 (voltou em pé)."""
        return 1.0 - clamp(self.moonwalk_timer / max(0.01, self.power_duration), 0.0, 1.0)

    @property
    def invulnerable(self):
        return self.invulnerable_timer > 0

    @property
    def moonwalk_ratio(self):
        """0.0 = recarregando ... 1.0 = pronto para usar (usado na barra do HUD)."""
        return 1.0 - clamp(self.moonwalk_cooldown / self.power_cooldown_total, 0.0, 1.0)

    # ------------------------------------------------------------ ações
    def start_moonwalk(self):
        if self.moonwalk_cooldown > 0 or self.state == "victory":
            return False
        self.moonwalk_timer = self.power_duration
        self.moonwalk_cooldown = self.power_cooldown_total
        return True

    start_power = start_moonwalk        # nome genérico (serve para moonwalk e inclinação)

    def hurt(self, duration=settings.HIT_ANIM_TIME):
        """Toma dano. Devolve False se estiver invencível (não perde vida)."""
        if self.invulnerable or self.shielded:
            return False
        self.hit_timer = duration
        self.invulnerable_timer = settings.INVULNERABLE_TIME
        return True

    def celebrate(self):
        self.play("victory")

    # ------------------------------------------------------------ atualização
    def update(self, dt, direction=0):
        """direction: -1 (esquerda), 0 (parado) ou +1 (direita)."""
        self.hit_timer = max(0.0, self.hit_timer - dt)
        self.invulnerable_timer = max(0.0, self.invulnerable_timer - dt)
        was_leaning = self.leaning
        self.moonwalk_timer = max(0.0, self.moonwalk_timer - dt)
        self.moonwalk_cooldown = max(0.0, self.moonwalk_cooldown - dt)
        if was_leaning and not self.leaning:
            self.grace_timer = settings.LEAN_GRACE          # acabou de voltar em pé: ainda protegido
        else:
            self.grace_timer = max(0.0, self.grace_timer - dt)

        if self.state == "victory":
            self.tick_animation(dt)
            return

        speed = settings.PLAYER_SPEED * (settings.MOONWALK_SPEED_MULT if self.moonwalking else 1.0)
        if self.leaning and not settings.LEAN_CAN_MOVE:
            speed = 0.0                                     # inclinado: fica parado no lugar
        half = self.rect.width / 2
        self.x = clamp(self.x + direction * speed * dt, half, settings.SCREEN_WIDTH - half)

        if self.hit_timer > 0:
            self.play("hit")
        elif self.leaning:
            self.play("lean" if "lean" in self.anims else "moonwalk")
        elif self.moonwalking:
            self.play("moonwalk")
        elif direction < 0:
            self.play("walk_left")
        elif direction > 0:
            self.play("walk_right")
        else:
            self.play("idle")

        self.tick_animation(dt)
        self.rect.midbottom = (round(self.x), self.floor_y)

    # frames da animação "lean": 0..4 = inclinando até 45°, 5..7 = voltando
    @staticmethod
    def _lean_frame(p, count=8):
        if p < 0.25:
            return min(4, int(p / 0.25 * 5))
        if p <= 0.75:
            return 4
        return min(count - 1, 5 + int((p - 0.75) / 0.25 * (count - 5)))

    def tick_animation(self, dt):
        if self.leaning and self.state == "lean":
            # o frame segue o PROGRESSO do poder (vai, fica um tempinho e volta)
            self.anim.time = (self._lean_frame(self.lean_progress, len(self.anim.frames)) + 0.5) / self.anim.fps
            return
        self.anim.update(dt)

    # ------------------------------------------------------------ desenho
    def draw(self, surface):
        # pisca enquanto está invencível (menos durante a animação de dano)
        if self.invulnerable and self.hit_timer <= 0 and int(self.invulnerable_timer * 14) % 2 == 0:
            return
        img = self.anim.image
        # os pés no sprite ficam ~12 px acima da borda de baixo da imagem
        bottom = self.floor_y + int(12 * self._skin_scale(self.skin))
        rect = img.get_rect(midbottom=(round(self.x), bottom))
        if self.moonwalking:
            surface.blit(self.aura, self.aura.get_rect(center=rect.center), special_flags=pygame.BLEND_ADD)
        surface.blit(img, rect)
