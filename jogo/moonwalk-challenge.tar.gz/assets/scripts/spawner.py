"""
spawner.py
==========
Cria obstáculos e coletáveis fora da tela (acima do topo), com aleatoriedade
controlada para o jogo nunca ficar injusto.

Regras de justiça:
  * nunca nasce um obstáculo colado em outro obstáculo recém-criado
    (sempre sobra um "corredor" livre para o jogador passar);
  * coletáveis não nascem em cima de obstáculos;
  * existe um limite máximo de obstáculos na tela em cada fase.
"""
import random

from scripts import settings
from scripts.collectible import Collectible
from scripts.obstacle import Obstacle
from scripts.utils import lerp


class Spawner:
    def __init__(self, assets, obstacles, collectibles):
        self.assets = assets
        self.obstacles = obstacles
        self.collectibles = collectibles
        self.reset()

    def reset(self):
        self.obstacle_timer = 1.3
        self.collectible_timer = 0.4

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _interval(pair, ramp):
        """Intervalo entre spawns, interpolado pela rampa de dificuldade."""
        base = lerp(pair[0], pair[1], ramp) / max(0.1, settings.SPAWN_RATE)
        return base * random.uniform(0.8, 1.25)

    def _free_x_for_obstacle(self):
        margin = 70
        for _ in range(12):
            x = random.randint(margin, settings.SCREEN_WIDTH - margin)
            # se já tem obstáculo recém-nascido perto desse x, tenta outro lugar
            if all(not (o.rect.centery < 260 and abs(o.rect.centerx - x) < 260) for o in self.obstacles):
                return x
        return None

    def _free_x_for_collectible(self):
        margin = 80
        for _ in range(12):
            x = random.randint(margin, settings.SCREEN_WIDTH - margin)
            if all(not (o.rect.centery < 220 and abs(o.rect.centerx - x) < 120) for o in self.obstacles):
                return x
        return random.randint(margin, settings.SCREEN_WIDTH - margin)

    # ------------------------------------------------------------ principal
    def update(self, dt, phase, ramp):
        self.obstacle_timer -= dt
        self.collectible_timer -= dt

        if self.obstacle_timer <= 0:
            if len(self.obstacles) < phase["max_obstacles"]:
                x = self._free_x_for_obstacle()
                if x is not None:
                    kind = random.choice(phase["obstacle_types"])
                    self.obstacles.add(Obstacle(kind, x, self.assets))
                    self.obstacle_timer = self._interval(phase["obstacle_interval"], ramp)
                else:
                    self.obstacle_timer = 0.25       # tenta de novo logo em seguida
            else:
                self.obstacle_timer = 0.3

        if self.collectible_timer <= 0:
            kinds = list(settings.COLLECTIBLE_WEIGHTS.keys())
            weights = list(settings.COLLECTIBLE_WEIGHTS.values())
            kind = random.choices(kinds, weights=weights)[0]
            self.collectibles.add(Collectible(kind, self._free_x_for_collectible(), self.assets))
            self.collectible_timer = self._interval(phase["collectible_interval"], ramp)
