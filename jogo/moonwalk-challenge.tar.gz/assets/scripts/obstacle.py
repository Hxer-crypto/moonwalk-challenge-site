"""
obstacle.py
===========
Obstáculos que caem do topo: SPEAKER, MICROPHONE e STAGE_LIGHT.

Cada um tem um comportamento simples (sem IA):
  - speaker:     cai reto, tremendo com o "grave"
  - microphone:  cai balançando de um lado para o outro
  - stage_light: cai na diagonal e "quica" nas laterais da tela
"""
import math
import random

import pygame

from scripts import settings
from scripts.utils import tint


class Obstacle(pygame.sprite.Sprite):
    KINDS = {
        "speaker": dict(hitbox=(64, 84), speed=1.0),
        "microphone": dict(hitbox=(30, 84), speed=0.95),
        "stage_light": dict(hitbox=(58, 58), speed=0.9),
    }
    MIC_ANGLES = list(range(-24, 25, 4))
    _cache = {}

    @classmethod
    def _images(cls, kind, assets):
        key = (kind, id(assets.images[kind]))
        if key not in cls._cache:
            base = assets.images[kind]
            if kind == "microphone":
                imgs = [pygame.transform.rotozoom(base, a, 1.0) for a in cls.MIC_ANGLES]
            else:
                imgs = [base]
            glow = tint(assets.images["glow"], (255, 60, 70))
            glow = pygame.transform.smoothscale(glow, (130, 130))
            cls._cache[key] = (imgs, glow)
        return cls._cache[key]

    def __init__(self, kind, x, assets, y=-70):
        super().__init__()
        cfg = self.KINDS[kind]
        self.kind = kind
        self.speed_mult = cfg["speed"] * random.uniform(0.92, 1.12)
        self.t = random.uniform(0, 6)
        self.phase = random.uniform(0, math.tau)
        margin = 130 if kind == "microphone" else 60
        self.base_x = min(max(x, margin), settings.SCREEN_WIDTH - margin)
        self.x = self.base_x
        self.y = float(y)
        self.vx = random.choice((-1, 1)) * random.uniform(90, 150) if kind == "stage_light" else 0.0
        self.rect = pygame.Rect(0, 0, *cfg["hitbox"])
        self.rect.center = (round(self.x), round(self.y))
        self.images, self.glow = self._images(kind, assets)
        self.frame = len(self.images) // 2

    def update(self, dt, fall_speed):
        self.t += dt
        self.y += fall_speed * self.speed_mult * dt
        if self.kind == "microphone":
            wave = self.t * 1.7 + self.phase
            self.x = self.base_x + math.sin(wave) * 80
            angle = -math.cos(wave) * 22           # inclina conforme balança
            self.frame = min(range(len(self.MIC_ANGLES)), key=lambda i: abs(self.MIC_ANGLES[i] - angle))
        elif self.kind == "stage_light":
            self.x += self.vx * dt
            if self.x < 50 or self.x > settings.SCREEN_WIDTH - 50:
                self.vx = -self.vx
                self.x = min(max(self.x, 50), settings.SCREEN_WIDTH - 50)
        self.rect.center = (round(self.x), round(self.y))

    def is_offscreen(self):
        return self.rect.bottom > settings.FLOOR_KILL_Y

    def draw(self, surface):
        cx, cy = self.rect.center
        if self.kind == "speaker":
            cx += int(math.sin(self.t * 45) * 2)        # tremor do grave
        pulse = 0.6 + 0.4 * math.sin(self.t * 6)
        glow = self.glow
        if pulse < 0.9:
            size = int(130 * (0.75 + 0.25 * pulse))
            glow = pygame.transform.scale(self.glow, (size, size))
        surface.blit(glow, glow.get_rect(center=(cx, cy)), special_flags=pygame.BLEND_ADD)
        img = self.images[self.frame]
        surface.blit(img, img.get_rect(center=(cx, cy)))
