"""
utils.py
========
Funções pequenas e reutilizáveis: caminhos, matemática, recorde (high score).
"""
import json
import math
import os
import sys

import pygame

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HIGHSCORE_FILE = os.path.join(BASE_DIR, "highscore.json")


def resource_path(*parts):
    """Monta um caminho a partir da pasta raiz do projeto."""
    return os.path.join(BASE_DIR, *parts)


def clamp(value, low, high):
    return max(low, min(high, value))


def lerp(a, b, t):
    """Interpolação linear entre a e b (t vai de 0 a 1)."""
    return a + (b - a) * t


def ease_out_back(t):
    """Easing com 'estouro' no final (bom para títulos que entram na tela)."""
    t = clamp(t, 0.0, 1.0)
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def star_points(cx, cy, r_out, r_in=None, points=5, rot=-math.pi / 2):
    """Lista de pontos de uma estrela (para pygame.draw.polygon)."""
    if r_in is None:
        r_in = r_out * 0.45
    pts = []
    for i in range(points * 2):
        r = r_out if i % 2 == 0 else r_in
        a = rot + i * math.pi / points
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return pts


def tint(surface, color):
    """Devolve uma cópia da imagem multiplicada por uma cor."""
    s = surface.copy()
    s.fill((color[0], color[1], color[2], 255), special_flags=pygame.BLEND_RGBA_MULT)
    return s


def blit_alpha(dst, src, pos, alpha):
    """Desenha uma imagem com transparência (alpha 0-255) sem alterar a original."""
    if alpha <= 0:
        return
    tmp = src.copy()
    tmp.set_alpha(int(clamp(alpha, 0, 255)))
    dst.blit(tmp, pos)


# ------------------------------------------------------------------ ARMAZENAMENTO NO NAVEGADOR
def _web_storage():
    """No navegador (pygbag) o recorde e as configurações ficam no localStorage; no PC, em arquivos."""
    if sys.platform != "emscripten":
        return None
    try:
        import platform
        return platform.window.localStorage
    except Exception:
        return None


def _web_get(key):
    st = _web_storage()
    if st is None:
        return None
    try:
        raw = st.getItem(key)
        return json.loads(str(raw)) if raw else None
    except Exception:
        return None


def _web_set(key, data):
    st = _web_storage()
    if st is None:
        return False
    try:
        st.setItem(key, json.dumps(data))
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ RECORDE
def load_high_score():
    """Lê o recorde de highscore.json (0 se o arquivo não existir ou estiver quebrado)."""
    if sys.platform == "emscripten":
        data = _web_get("mj_highscore")
        try:
            return int(data.get("high_score", 0)) if isinstance(data, dict) else 0
        except (ValueError, TypeError):
            return 0
    try:
        with open(HIGHSCORE_FILE, "r", encoding="utf-8") as f:
            return int(json.load(f).get("high_score", 0))
    except (OSError, ValueError, TypeError, AttributeError):
        return 0


def save_high_score(value):
    """Salva o recorde. Se não conseguir gravar, o jogo continua normalmente."""
    if _web_set("mj_highscore", {"high_score": int(value)}):
        return
    try:
        with open(HIGHSCORE_FILE, "w", encoding="utf-8") as f:
            json.dump({"high_score": int(value)}, f)
    except OSError as err:
        print(f"[AVISO] Não foi possível salvar o recorde: {err}")


# ------------------------------------------------------------------ CONFIGURAÇÕES DO JOGADOR
USER_SETTINGS_FILE = os.path.join(BASE_DIR, "user_settings.json")


def load_user_settings():
    """Lê as preferências (volumes, música on/off...). Devolve {} se não existir."""
    if sys.platform == "emscripten":
        data = _web_get("mj_user_settings")
        if isinstance(data, dict):
            return data
    try:
        with open(USER_SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_user_settings(data):
    """Salva as preferências. Se falhar, o jogo continua normalmente."""
    if _web_set("mj_user_settings", data):
        return
    try:
        with open(USER_SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError as err:
        print(f"[AVISO] Não foi possível salvar as configurações: {err}")
