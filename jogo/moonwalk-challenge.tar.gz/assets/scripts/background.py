"""
background.py
=============
Cenário em camadas com parallax simples:

    BACKGROUND : fundo escuro + refletores/treliça   (lights balança devagar)
    MIDGROUND  : público em silhueta + palco (floor)
    FOREGROUND : vinheta escura nas bordas (bg_front)

Além das camadas prontas (PNG), existem "raios de luz" dinâmicos: são
desenhados em baixa resolução e ampliados, o que deixa a luz macia e barata.
"""
import math
import random

import pygame

from scripts import settings


class LightRays:
    """Feixes de luz que balançam. Desenhados em 320x180 e ampliados."""

    def __init__(self, count, colors, w=320, h=180):
        self.count = count
        self.colors = colors
        self.w, self.h = w, h
        self.surf = pygame.Surface((w, h), 0, 32)
        self.t = random.uniform(0, 10)

    def update(self, dt):
        self.t += dt

    def draw(self, target, strength=0.32):
        s = self.surf
        s.fill((0, 0, 0))
        length = self.h * 1.15
        for i in range(self.count):
            ox = (i + 0.5) / self.count * self.w
            ang = math.sin(self.t * (0.55 + 0.11 * i) + i * 1.9) * 0.55
            width = 0.075 + 0.03 * math.sin(self.t * 0.9 + i)
            col = self.colors[i % len(self.colors)]
            col = tuple(int(c * strength) for c in col)
            pts = [(ox, 0),
                   (ox + math.sin(ang - width) * length, math.cos(ang - width) * length),
                   (ox + math.sin(ang + width) * length, math.cos(ang + width) * length)]
            pygame.draw.polygon(s, col, pts)
        # reduz e amplia de novo: isso "borra" as bordas e deixa a luz macia
        soft = pygame.transform.smoothscale(s, (self.w // 3, self.h // 3))
        big = pygame.transform.smoothscale(soft, target.get_size())
        target.blit(big, (0, 0), special_flags=pygame.BLEND_ADD)


class ParallaxBackground:
    def __init__(self, assets, name, beams=0, beam_colors=None, crowd_sway=True):
        im = assets.images
        self.name = name
        self.back = im[f"bg_{name}_back"]
        self.lights = im[f"bg_{name}_lights"]
        self.crowd = im[f"bg_{name}_crowd"]
        self.floor = im[f"bg_{name}_floor"]
        self.front = im["bg_front"]
        self.crowd_sway = crowd_sway     # False = cenário fixo (colunas, prédios...)
        self.rays = None
        if beams > 0:
            colors = beam_colors or [(140, 100, 255), (255, 200, 90), (90, 180, 255)]
            self.rays = LightRays(beams, colors)
        self.t = random.uniform(0, 10)

    def update(self, dt):
        self.t += dt
        if self.rays:
            self.rays.update(dt)

    def draw_back(self, surface):
        """Desenha BACKGROUND + MIDGROUND (tudo que fica ATRÁS do personagem)."""
        surface.blit(self.back, (0, 0))
        pad = (self.lights.get_width() - settings.SCREEN_WIDTH) // 2
        self.lights.set_alpha(int(215 + 40 * math.sin(self.t * 1.6)))
        surface.blit(self.lights, (-pad + math.sin(self.t * 0.5) * 22, 0))
        if self.rays:
            self.rays.draw(surface)
        # público balançando de leve (cenários de arquitetura ficam parados)
        sway_x = -pad + (math.sin(self.t * 0.3) * 10 if self.crowd_sway else 0)
        bob_y = math.sin(self.t * 3.2) * 2 if self.crowd_sway else 0
        surface.blit(self.crowd, (sway_x, bob_y))
        surface.blit(self.floor, (0, 0))

    def draw_front(self, surface):
        """FOREGROUND: vinheta (não esconde o personagem)."""
        surface.blit(self.front, (0, 0))
