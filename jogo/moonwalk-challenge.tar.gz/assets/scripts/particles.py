"""
particles.py
============
Sistema simples de partículas + fumaça de palco + textos flutuantes ("+20").

Uma partícula é só: posição, velocidade, tempo de vida, tamanho, cor e formato.
Ela encolhe e escurece até sumir (o fundo é escuro, então "escurecer" = "sumir").
"""
import math
import random

import pygame

from scripts import settings
from scripts.utils import star_points, tint, clamp


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "size", "color",
                 "shape", "gravity", "rot", "spin")

    def __init__(self, x, y, vx, vy, life, size, color, shape, gravity, spin):
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.life = self.max_life = life
        self.size = size
        self.color = color
        self.shape = shape
        self.gravity = gravity
        self.rot = random.uniform(0, math.tau)
        self.spin = spin


class ParticleSystem:
    MAX_PARTICLES = 700   # limite para nunca pesar

    def __init__(self):
        self.particles = []

    def clear(self):
        self.particles.clear()

    def emit(self, x, y, count, colors, speed=(60, 240), life=(0.4, 0.9), size=(3, 7),
             shape="circle", gravity=0.0, angle=(0, 360), spin=(-6, 6)):
        """Cria 'count' partículas saindo de (x, y).

        shape: "circle", "square", "star" ou "spark".
        angle: intervalo de direções em graus (0 = direita, 270 = para cima).
        """
        if isinstance(colors, tuple) and isinstance(colors[0], int):
            colors = [colors]
        if settings.PARTICLE_SCALE < 1.0:                 # modo "qualidade baixa" (celular)
            count = max(1, int(count * settings.PARTICLE_SCALE))
        for _ in range(count):
            if len(self.particles) >= self.MAX_PARTICLES * settings.PARTICLE_SCALE:
                return
            a = math.radians(random.uniform(*angle))
            s = random.uniform(*speed)
            self.particles.append(Particle(
                x, y, math.cos(a) * s, math.sin(a) * s,
                random.uniform(*life), random.uniform(*size),
                random.choice(colors), shape, gravity, random.uniform(*spin)))

    def update(self, dt):
        alive = []
        for p in self.particles:
            p.life -= dt
            if p.life <= 0:
                continue
            p.vy += p.gravity * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rot += p.spin * dt
            alive.append(p)
        self.particles = alive

    def draw(self, surface):
        for p in self.particles:
            t = p.life / p.max_life
            k = 0.35 + 0.65 * t
            color = (int(p.color[0] * k), int(p.color[1] * k), int(p.color[2] * k))
            size = max(1.0, p.size * (0.4 + 0.6 * t))
            pos = (int(p.x), int(p.y))
            if p.shape == "square":
                s = int(size * 1.6)
                pygame.draw.rect(surface, color, (pos[0] - s // 2, pos[1] - s // 2, s, s))
            elif p.shape == "star":
                pygame.draw.polygon(surface, color, star_points(p.x, p.y, size * 1.6, size * 0.7, 5, p.rot))
            elif p.shape == "spark":
                end = (p.x - p.vx * 0.05, p.y - p.vy * 0.05)
                pygame.draw.line(surface, color, pos, (int(end[0]), int(end[1])), max(1, int(size / 2)))
            else:
                pygame.draw.circle(surface, color, pos, max(1, int(size)))


class FloatingText:
    """Texto que sobe e some (ex.: '+20')."""

    def __init__(self, text, x, y, color, size=30, life=0.9):
        self.text, self.x, self.y = text, x, y
        self.color, self.size = color, size
        self.life = self.max_life = life

    def update(self, dt):
        self.life -= dt
        self.y -= 60 * dt

    @property
    def alive(self):
        return self.life > 0

    def draw(self, surface, assets):
        img = assets.render_text(self.text, self.size, self.color, outline=2, outline_color=(20, 10, 40))
        img = img.copy()
        img.set_alpha(int(255 * clamp(self.life / self.max_life * 1.6, 0, 1)))
        surface.blit(img, img.get_rect(center=(int(self.x), int(self.y))))


class SmokeLayer:
    """Fumaça de palco: algumas nuvens suaves andando devagar perto do chão."""

    def __init__(self, assets, count=9, level=0.6, color=(150, 130, 210), y_range=(560, 705)):
        self.count = count
        self.y_range = y_range
        base = tint(assets.images["smoke"], color)
        self.sizes = [pygame.transform.smoothscale(base, (s, int(s * 0.55))) for s in (240, 340, 460)]
        self.level = level * settings.SMOKE_SCALE
        self.puffs = []
        for _ in range(count):
            self.puffs.append({
                "x": random.uniform(-200, settings.SCREEN_WIDTH),
                "y": random.uniform(*y_range),
                "vx": random.uniform(8, 24) * random.choice((-1, 1)),
                "size": random.randrange(len(self.sizes)),
                "phase": random.uniform(0, math.tau),
            })
        self.t = 0.0

    def set_level(self, level):
        self.level = level * settings.SMOKE_SCALE

    def update(self, dt):
        self.t += dt
        for p in self.puffs:
            p["x"] += p["vx"] * dt
            if p["x"] > settings.SCREEN_WIDTH + 100:
                p["x"] = -self.sizes[p["size"]].get_width()
            elif p["x"] < -self.sizes[p["size"]].get_width() - 100:
                p["x"] = settings.SCREEN_WIDTH

    def draw(self, surface):
        for p in self.puffs:
            img = self.sizes[p["size"]]
            alpha = int((28 + 22 * math.sin(self.t * 0.6 + p["phase"])) * (0.4 + self.level))
            img.set_alpha(max(0, min(255, alpha)))
            surface.blit(img, (int(p["x"]), int(p["y"] + math.sin(self.t * 0.4 + p["phase"]) * 6)))
