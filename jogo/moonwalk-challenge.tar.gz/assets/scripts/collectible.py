"""
collectible.py
==============
Itens que dão pontos: STAR (+10), MUSIC_NOTE (+20) e GOLDEN_STAR (+50).

Cada item cai do topo balançando de leve, gira/pulsa e tem um brilho atrás.
As imagens animadas são calculadas UMA vez (cache) e reaproveitadas.
"""
import math
import random

import pygame

from scripts import settings
from scripts.utils import tint


class Collectible(pygame.sprite.Sprite):
    KINDS = {
        "star": dict(points=settings.STAR_POINTS, sound="collect_star", glow=(255, 235, 140),
                     sway=18, speed=0.9, hitbox=44, particles=[(255, 240, 150), (255, 255, 255)]),
        "note": dict(points=settings.NOTE_POINTS, sound="collect_note", glow=(120, 190, 255),
                     sway=40, speed=0.85, hitbox=44, particles=[(120, 200, 255), (200, 160, 255)]),
        "golden_star": dict(points=settings.GOLDEN_STAR_POINTS, sound="collect_golden", glow=(255, 190, 40),
                            sway=70, speed=1.15, hitbox=52, particles=[(255, 205, 60), (255, 245, 170)]),
    }
    FRAMES = 16
    _cache = {}

    @classmethod
    def _frames(cls, kind, assets):
        """Lista de (imagem, brilho) já prontas para desenhar."""
        key = (kind, id(assets.images[kind]))
        if key not in cls._cache:
            cfg = cls.KINDS[kind]
            base = assets.images[kind]
            glow_base = tint(assets.images["glow"], cfg["glow"])
            frames = []
            for i in range(cls.FRAMES):
                phase = i / cls.FRAMES
                pulse = 1.0 + 0.10 * math.sin(math.tau * phase)
                angle = 12 * math.sin(math.tau * phase) if kind == "note" else phase * 72
                img = pygame.transform.rotozoom(base, angle, pulse)
                gsize = int(92 + 14 * math.sin(math.tau * phase + 1.0))
                glow = pygame.transform.smoothscale(glow_base, (gsize, gsize))
                frames.append((img, glow))
            cls._cache[key] = frames
        return cls._cache[key]

    def __init__(self, kind, x, assets, y=-40):
        super().__init__()
        cfg = self.KINDS[kind]
        self.kind = kind
        self.points = cfg["points"]
        self.sound = cfg["sound"]
        self.particle_colors = cfg["particles"]
        self.speed_mult = cfg["speed"]
        self.sway = cfg["sway"]
        margin = 40 + self.sway
        self.base_x = min(max(x, margin), settings.SCREEN_WIDTH - margin)
        self.x = self.base_x
        self.y = float(y)
        self.t = random.uniform(0, 6)
        self.phase = random.uniform(0, math.tau)
        self.freq = 2.2 if kind != "golden_star" else 3.4
        size = cfg["hitbox"]
        self.rect = pygame.Rect(0, 0, size, size)
        self.rect.center = (round(self.x), round(self.y))
        self.frames = self._frames(kind, assets)
        self.attracted = False          # True = está sendo puxado pelo ímã (poder do Smooth Criminal)

    def attract(self, dt, target, speed):
        """Puxa o item em direção a 'target' (x, y) com 'speed' px/s."""
        dx, dy = target[0] - self.x, target[1] - self.y
        dist = math.hypot(dx, dy)
        if dist < 1:
            return
        step = min(dist, speed * dt)
        self.x += dx / dist * step
        self.y += dy / dist * step
        self.base_x = self.x
        self.attracted = True

    def update(self, dt, fall_speed):
        self.t += dt
        if self.attracted:              # o ímã manda: não cai nem balança neste quadro
            self.attracted = False
            self.rect.center = (round(self.x), round(self.y))
            return
        self.y += fall_speed * self.speed_mult * dt
        self.x = self.base_x + math.sin(self.t * self.freq + self.phase) * self.sway
        self.rect.center = (round(self.x), round(self.y))

    def is_offscreen(self):
        return self.rect.bottom > settings.FLOOR_KILL_Y

    def draw(self, surface):
        img, glow = self.frames[int(self.t * 12) % len(self.frames)]
        surface.blit(glow, glow.get_rect(center=self.rect.center), special_flags=pygame.BLEND_ADD)
        surface.blit(img, img.get_rect(center=self.rect.center))
